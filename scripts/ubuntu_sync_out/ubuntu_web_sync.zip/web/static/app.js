/**
 * 企業管理系統 Web 前端 — 對齊 Windows WorkPage / RecordDetailPage 工作流程
 */
(function () {
  "use strict";

  const TOKEN_KEY = "wolee_web_token";
  const USER_KEY = "wolee_web_user";
  const MENU_MODE_KEY = "wolee_menu_mode";
  const MENU_MODE_DEFAULT = "TREE";
  const FONT_PT_KEY = "wolee_ui_font_pt";
  const FONT_PT_DEFAULT = { gridCell: 10, gridHeader: 11, formLabel: 12, formEditor: 11 };
  const FONT_PT_MIN = 6;
  const FONT_PT_MAX = 28;

  function loadFontPt() {
    try {
      const raw = JSON.parse(localStorage.getItem(FONT_PT_KEY) || "null");
      if (raw && typeof raw === "object") {
        return {
          gridCell: Number(raw.gridCell) || FONT_PT_DEFAULT.gridCell,
          gridHeader: Number(raw.gridHeader) || FONT_PT_DEFAULT.gridHeader,
          formLabel: Number(raw.formLabel) || FONT_PT_DEFAULT.formLabel,
          formEditor: Number(raw.formEditor) || FONT_PT_DEFAULT.formEditor,
        };
      }
    } catch (_) {}
    return { ...FONT_PT_DEFAULT };
  }

  function saveFontPt(s) {
    localStorage.setItem(FONT_PT_KEY, JSON.stringify(s));
  }

  function applyFontPtToDocument() {
    const s = loadFontPt();
    const root = document.documentElement.style;
    root.setProperty("--grid-cell-pt", String(s.gridCell));
    root.setProperty("--grid-header-pt", String(s.gridHeader));
    root.setProperty("--form-label-pt", String(s.formLabel));
    root.setProperty("--form-editor-pt", String(s.formEditor));
  }

  function clampFontPt(v, fallback) {
    const n = Number(v);
    if (!Number.isFinite(n)) return fallback;
    return Math.max(FONT_PT_MIN, Math.min(FONT_PT_MAX, Math.round(n)));
  }

  function bumpFontPt(kind, delta) {
    const s = loadFontPt();
    if (kind === "grid") {
      s.gridCell = clampFontPt(s.gridCell + delta, FONT_PT_DEFAULT.gridCell);
      s.gridHeader = clampFontPt(s.gridHeader + delta, FONT_PT_DEFAULT.gridHeader);
    } else {
      s.formLabel = clampFontPt(s.formLabel + delta, FONT_PT_DEFAULT.formLabel);
      s.formEditor = clampFontPt(s.formEditor + delta, FONT_PT_DEFAULT.formEditor);
    }
    saveFontPt(s);
    applyFontPtToDocument();
  }

  function fontToolbarButtonsHtml() {
    return `
      ${iconBtn(t("fontGridMinus"), "filter", "btn secondary font-btn topbar-btn", 'data-font="grid-minus"', t("fontGridMinusTitle"))}
      ${iconBtn(t("fontGridPlus"), "add", "btn secondary font-btn topbar-btn", 'data-font="grid-plus"', t("fontGridPlusTitle"))}
      ${iconBtn(t("fontFormMinus"), "edit", "btn secondary font-btn topbar-btn", 'data-font="form-minus"', t("fontFormMinusTitle"))}
      ${iconBtn(t("fontFormPlus"), "create_table", "btn secondary font-btn topbar-btn", 'data-font="form-plus"', t("fontFormPlusTitle"))}`;
  }

  function refreshTopbarI18n() {
    mountSystemFontToolbar();
    setButtonIcon($("#btn-switch-desktop"), "language", t("switchDesktop"));
    setButtonIcon($("#btn-logout"), "exit", t("logout"));
    const langLab = document.querySelector(".lang-label");
    if (langLab) langLab.textContent = t("langLabel");
  }

  function mountSystemFontToolbar() {
    const host = $("#font-toolbar");
    if (!host) return;
    host.innerHTML = fontToolbarButtonsHtml();
    host.querySelectorAll(".font-btn[data-font]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const parts = (btn.dataset.font || "").split("-");
        if (parts.length !== 2) return;
        bumpFontPt(parts[0], parts[1] === "plus" ? 1 : -1);
      });
    });
  }

  const I18N = {
    CHN: {
      searchLabel: "搜尋:",
      search: "搜尋",
      filter: "過濾",
      add: "新增",
      edit: "更改",
      del: "刪除",
      copy: "複製",
      print: "列印預覽",
      exit: "離開",
      navFirst: "首筆",
      navPrev: "上筆",
      navNext: "下筆",
      navLast: "末筆",
      recordNav: (c, t) => (c != null && c > 0 ? `${c}/${t}` : `-/${t}`),
      save: "儲存",
      cancel: "取消",
      detailSuffix: "明細",
      formData: "資 料",
      formDetail: "明 細",
      selectRow: "請先選取一筆記錄。",
      confirmDel: "確定要刪除所選記錄嗎？",
      deleted: "已刪除。",
      delFail: "刪除失敗。",
      noPrint: "無資料可列印。",
      printTitle: "列印報表",
      printPrinter: "印表機:",
      printReport: "報表:",
      printFromNo: (label) => `由${label}編號:`,
      printToNo: (label) => `至${label}編號:`,
      printFromDate: "由日期:",
      printToDate: "至日期:",
      printPreview: "預覽",
      printBtn: "列印",
      printExportPdf: "匯出 PDF",
      printExportXlsx: "匯出 XLSX",
      printExportDocx: "匯出 DOCX",
      printEmail: "電郵",
      printExit: "離開",
      printNoReport: "沒有可列印的報表 !\nNo Report Print !",
      printPickRecord: "選擇記錄",
      printPickFilter: "輸入關鍵字過濾（GRID）",
      printPickOk: "確定",
      printPickCancel: "取消",
      printPickBtn: "選取",
      printDatePickBtn: "選取日期",
      printClearDate: "清除日期",
      printPickNoKey: "找不到可選擇的主編號欄位。",
      printPickNoData: "目前沒有可選擇的資料。",
      printSuccess: (msg) => msg || "完成。",
      printFail: "列印失敗。",
      printPreviewFail: "預覽失敗。",
      printPreviewTitle: "列印預覽",
      printPreviewOpenWindow: "新視窗",
      printPreviewClose: "關閉預覽",
      printPreviewBlocked: "無法開啟新視窗，已改在本頁顯示預覽。",
      printPreviewPdfNav: (c, t) => `${c} / ${t}`,
      printExportFail: "匯出失敗。",
      printExportOk: (name) => `已匯出：${name}`,
      printEmailCopied: "報表全文已複製到剪貼簿，請在郵件本文按 Ctrl+V 貼上。",
      printDesktop: "完整列印預覽（含報表選擇）請使用桌面版「列印預覽」按鈕。",
      emptyMenu: "請從左側主選單選擇作業",
      addTitle: (t) => `新增 - ${t}`,
      editTitle: (t) => `${t}`,
      noData: "無資料",
      confirmTxDel: "刪除此列？",
      txSaveFail: "主檔已儲存，但交易明細儲存失敗：",
      fontGridMinus: "Grid字體−(含標題)",
      fontGridPlus: "Grid字體+(含標題)",
      fontFormMinus: "表單字體−",
      fontFormPlus: "表單字體+",
      fontGridMinusTitle: "Grid 字體減少（含標題列）",
      fontGridPlusTitle: "Grid 字體增加（含標題列）",
      fontFormMinusTitle: "表單字體減少",
      fontFormPlusTitle: "表單字體增加",
      langLabel: "語言",
      switchDesktop: "桌面介面",
      logout: "登出",
      attachment: "附件",
      otherDefault: "其他",
      attachSelectRow: "請先選取一筆記錄。",
      attachPath: (p) => `附件目錄：\n${p}`,
      attachNoFiles: (folder, key) => `在以下目錄找不到符合「${key}」的附件：\n${folder}`,
      attachPreview: "附件預覽",
      attachClose: "關閉",
      arapTitleAR: "應收清賬",
      arapTitleAP: "應付清賬",
      arapAuto: "自動清賬",
      arapVouKey: "傳票編號",
      arapSettleDate: "清賬日期",
      arapPartyAR: "顧客編號-名稱",
      arapPartyAP: "供應商編號-名稱",
      arapSettleAmt: "清賬金額",
      arapExchDiff: "兌匯差額",
      arapSelectVoucher: "請先選取一筆傳票記錄。",
      arapSaved: "清賬已儲存。",
      menuModeTree: "樹狀",
      menuModeIcon: "圖示",
      menuModeList: "列表",
      menuModeToolbox: "折疊",
      menuModeTabs: "分頁",
      otherNotConfigured: "此功能尚未設定實作內容。",
    },
    ENG: {
      searchLabel: "Search:",
      search: "Search",
      filter: "Filter",
      add: "Add",
      edit: "Edit",
      del: "Delete",
      copy: "Copy",
      print: "Print Preview",
      exit: "Exit",
      navFirst: "First",
      navPrev: "Prev",
      navNext: "Next",
      navLast: "Last",
      recordNav: (c, t) => (c != null && c > 0 ? `${c}/${t}` : `-/${t}`),
      save: "Save",
      cancel: "Cancel",
      detailSuffix: "Detail",
      formData: "Data",
      formDetail: "Detail",
      selectRow: "Please select a record first.",
      confirmDel: "Delete selected record?",
      deleted: "Deleted.",
      delFail: "Delete failed.",
      noPrint: "No data to print.",
      printTitle: "Print Report",
      printPrinter: "Printer:",
      printReport: "Report:",
      printFromNo: (label) => `From ${label} no.:`,
      printToNo: (label) => `To ${label} no.:`,
      printFromDate: "From date:",
      printToDate: "To date:",
      printPreview: "Preview",
      printBtn: "Print",
      printExportPdf: "Export PDF",
      printExportXlsx: "Export XLSX",
      printExportDocx: "Export DOCX",
      printEmail: "Email",
      printExit: "Exit",
      printNoReport: "No Report Print !",
      printPickRecord: "Select record",
      printPickFilter: "Type to filter (grid)",
      printPickOk: "OK",
      printPickCancel: "Cancel",
      printPickBtn: "Select",
      printDatePickBtn: "Pick date",
      printClearDate: "Clear date",
      printPickNoKey: "Cannot find a key number column.",
      printPickNoData: "No records available.",
      printSuccess: (msg) => msg || "Done.",
      printFail: "Printing failed.",
      printPreviewFail: "Preview failed.",
      printPreviewTitle: "Print Preview",
      printPreviewOpenWindow: "New window",
      printPreviewClose: "Close preview",
      printPreviewBlocked: "Popup blocked; showing preview in this page.",
      printPreviewPdfNav: (c, t) => `${c} / ${t}`,
      printExportFail: "Export failed.",
      printExportOk: (name) => `Exported: ${name}`,
      printEmailCopied: "Full report copied to clipboard; paste with Ctrl+V in your mail app.",
      printDesktop: "For full print preview, use Desktop mode Print Preview.",
      emptyMenu: "Select a program from the main menu",
      addTitle: (t) => `Add - ${t}`,
      editTitle: (t) => t,
      noData: "No data",
      confirmTxDel: "Delete this row?",
      txSaveFail: "Master saved, but detail lines failed: ",
      fontGridMinus: "Grid − (header)",
      fontGridPlus: "Grid + (header)",
      fontFormMinus: "Form −",
      fontFormPlus: "Form +",
      fontGridMinusTitle: "Decrease grid font (incl. header row)",
      fontGridPlusTitle: "Increase grid font (incl. header row)",
      fontFormMinusTitle: "Decrease form font",
      fontFormPlusTitle: "Increase form font",
      langLabel: "Language",
      switchDesktop: "Desktop",
      logout: "Logout",
      attachment: "Attachment",
      otherDefault: "Other",
      attachSelectRow: "Please select a record first.",
      attachPath: (p) => `Attachment folder:\n${p}`,
      attachNoFiles: (folder, key) => `No attachment matching "${key}" in:\n${folder}`,
      attachPreview: "Attachment Preview",
      attachClose: "Close",
      arapTitleAR: "A/R Settlement",
      arapTitleAP: "A/P Settlement",
      arapAuto: "Auto Settle",
      arapVouKey: "Voucher No.",
      arapSettleDate: "Settle Date",
      arapPartyAR: "Customer No.-Name",
      arapPartyAP: "Vendor No.-Name",
      arapSettleAmt: "Settle Amount",
      arapExchDiff: "Exchange Diff.",
      arapSelectVoucher: "Please select a voucher record first.",
      arapSaved: "Settlement saved.",
      menuModeTree: "Tree",
      menuModeIcon: "Icons",
      menuModeList: "List",
      menuModeToolbox: "Toolbox",
      menuModeTabs: "Tabs",
      otherNotConfigured: "This action is not configured yet.",
    },
  };

  const GRID_VISIBLE_ROWS = 20;

  let token = localStorage.getItem(TOKEN_KEY) || "";
  let currentUser = null;
  let menuGroups = [];
  let openTabs = [];
  let activeTabId = null;
  let currentLang = "CHN";
  let formModalState = null;
  let attachModalState = null;
  let arapModalState = null;

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const loginView = $("#login-view");
  const mainView = $("#main-view");

  function t(key, ...args) {
    const pack = I18N[currentLang] || I18N.CHN;
    const v = pack[key];
    return typeof v === "function" ? v(...args) : v;
  }

  const PUBLIC_API_PATHS = new Set(["/companies", "/auth/login", "/auth/last-company", "/health"]);

  function apiErrorMessage(data, fallback) {
    if (!data || data.detail == null) return fallback;
    if (typeof data.detail === "string") return data.detail;
    if (Array.isArray(data.detail)) {
      return data.detail.map((d) => d.msg || String(d)).join("；") || fallback;
    }
    return fallback;
  }

  function isPublicApiPath(path) {
    const p = path.startsWith("/") ? path : `/${path}`;
    return PUBLIC_API_PATHS.has(p);
  }

  async function api(path, options = {}) {
    const normalizedPath = path.startsWith("/") ? path : `/${path}`;
    const isPublic = options.public === true || isPublicApiPath(normalizedPath);
    const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
    if (token && options.omitAuth !== true) headers.Authorization = `Bearer ${token}`;
    const res = await fetch(`/api${normalizedPath}`, { ...options, headers });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401) {
      if (!isPublic && token) {
        clearSession();
        showLogin();
      }
      throw new Error(apiErrorMessage(data, isPublic ? "登入失敗。" : "未登入或 session 已過期。"));
    }
    if (!res.ok) throw new Error(apiErrorMessage(data, res.statusText || "請求失敗"));
    return data;
  }

  function escapeHtml(s) {
    if (s == null) return "";
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function iconBtn(label, iconName, className, attrs = "", tooltip = null) {
    const tlt = escapeHtml(tooltip != null ? tooltip : label);
    const iconPx = /\btopbar-btn\b/.test(className) ? 18 : 16;
    return `<button type="button" class="${className} btn-has-icon" title="${tlt}" aria-label="${tlt}" ${attrs}>${uiIcon(iconName, iconPx)}<span class="btn-label">${escapeHtml(label)}</span></button>`;
  }

  function iconBtnOnly(label, iconName, className, attrs = "") {
    const tlt = escapeHtml(label);
    return `<button type="button" class="${className} btn-icon-only" title="${tlt}" aria-label="${tlt}" ${attrs}>${uiIcon(iconName, 16)}</button>`;
  }

  function setButtonIcon(el, iconName, label, tooltip = null) {
    if (!el) return;
    el.classList.add("btn-has-icon", "topbar-btn");
    const text = label != null ? label : el.textContent.trim();
    const tlt = tooltip != null ? tooltip : text;
    el.setAttribute("title", tlt);
    el.setAttribute("aria-label", tlt);
    el.innerHTML = `${uiIcon(iconName, 18)}<span class="btn-label">${escapeHtml(text)}</span>`;
  }

  function decorateChromeButtons() {
    setButtonIcon($("#btn-login-ok"), "dialog-ok");
    setButtonIcon($("#btn-login-cancel"), "cancel");
    refreshTopbarI18n();
  }

  function hideLoginError() {
    const errEl = $("#login-error");
    if (errEl) errEl.classList.add("hidden");
  }

  function showLoginError(message) {
    const errEl = $("#login-error");
    if (!errEl) return;
    errEl.textContent = message;
    errEl.classList.remove("hidden");
  }

  function showLogin() {
    loginView.classList.remove("hidden");
    mainView.classList.add("hidden");
  }

  function showMain() {
    loginView.classList.add("hidden");
    mainView.classList.remove("hidden");
    hideLoginError();
    refreshTopbarI18n();
  }

  function todayAppDate() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}/${m}/${day}`;
  }

  function normalizeAppDateText(val) {
    const v = (val || "").trim();
    if (!v) return "";
    const m = v.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
    if (!m) return v;
    return `${m[1]}/${String(m[2]).padStart(2, "0")}/${String(m[3]).padStart(2, "0")}`;
  }

  function parseAppDate(val) {
    const n = normalizeAppDateText(val);
    const m = n.match(/^(\d{4})\/(\d{2})\/(\d{2})$/);
    if (!m) return null;
    const y = parseInt(m[1], 10);
    const mo = parseInt(m[2], 10);
    const d = parseInt(m[3], 10);
    const dt = new Date(y, mo - 1, d);
    if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
    return { y, mo, d };
  }

  function lastDayOfMonth(y, mo) {
    return new Date(y, mo, 0).getDate();
  }

  function initLoginDate() {
    const dt = $("#login-date");
    if (dt && !dt.value) dt.value = todayAppDate();
  }

  async function loadCompanies() {
    const data = await api("/companies", { public: true });
    const sel = $("#login-company");
    sel.innerHTML = "";
    (data.companies || ["GS"]).forEach((co) => {
      const opt = document.createElement("option");
      opt.value = co;
      opt.textContent = co;
      sel.appendChild(opt);
    });
    if (!sel.value && sel.options.length) sel.selectedIndex = 0;
  }

  async function tryLastCompany(userNo, password) {
    if (!userNo || !password) return;
    try {
      const data = await api("/auth/last-company", {
        method: "POST",
        public: true,
        body: JSON.stringify({ user_no: userNo, password }),
      });
      if (data.company_key) {
        const sel = $("#login-company");
        if (![...sel.options].some((o) => o.value === data.company_key)) {
          const opt = document.createElement("option");
          opt.value = data.company_key;
          opt.textContent = data.company_key;
          sel.insertBefore(opt, sel.firstChild);
        }
        sel.value = data.company_key;
      }
    } catch (_) {}
  }

  async function login(userNo, password, companyKey) {
    hideLoginError();
    const selectedCo = (companyKey || $("#login-company").value || "").trim();
    try {
      await tryLastCompany(userNo, password);
      const co = selectedCo || ($("#login-company").value || "").trim();
      const data = await api("/auth/login", {
        method: "POST",
        public: true,
        omitAuth: true,
        body: JSON.stringify({ user_no: userNo, password, company_key: co }),
      });
      token = data.token;
      currentUser = data;
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(data));
      showMain();
      await refreshMenu();
      updateUserInfo();
    } catch (e) {
      showLoginError(e.message || "登入失敗。");
    }
  }

  function clearSession() {
    const oldToken = token;
    token = "";
    currentUser = null;
    openTabs = [];
    activeTabId = null;
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    if (oldToken) {
      fetch("/api/auth/logout", {
        method: "POST",
        headers: { Authorization: `Bearer ${oldToken}` },
      }).catch(() => {});
    }
  }

  function logout() {
    clearSession();
    showLogin();
    hideLoginError();
    initLoginDate();
  }

  async function restoreSession() {
    if (!token) return false;
    try {
      const data = await api("/auth/me");
      currentUser = { ...JSON.parse(localStorage.getItem(USER_KEY) || "{}"), ...data };
      localStorage.setItem(USER_KEY, JSON.stringify(currentUser));
      return true;
    } catch (_) {
      clearSession();
      return false;
    }
  }

  function updateUserInfo() {
    const el = $("#user-info");
    if (currentUser) el.textContent = `${currentUser.user_no} @ ${currentUser.company_key}`;
  }

  async function refreshMenu() {
    const data = await api("/menu");
    menuGroups = data.groups || [];
    currentLang = data.lang || "CHN";
    $("#lang-select").value = currentLang;
    renderMenu();
  }

  function loadMenuMode() {
    try {
      const v = localStorage.getItem(MENU_MODE_KEY);
      if (["TREE", "ICON_GRID", "LIST", "TOOLBOX", "TABS"].includes(v)) return v;
    } catch (_) {}
    return MENU_MODE_DEFAULT;
  }

  function saveMenuMode(mode) {
    localStorage.setItem(MENU_MODE_KEY, mode);
  }

  function menuItemIconName(item) {
    return item.icon || "applications-system";
  }

  function openProgramFromMenu(doProc, title) {
    openWorkTab(doProc, title);
  }

  function bindMenuItemOpen(el, doProc, title, useDblClick) {
    const open = () => openProgramFromMenu(doProc, title);
    if (useDblClick) {
      el.addEventListener("dblclick", (e) => {
        e.preventDefault();
        open();
      });
    } else {
      el.addEventListener("click", open);
    }
  }

  function createMenuItemButton(item, groupTitle, opts = {}) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = opts.className || "menu-item btn-has-icon";
    btn.dataset.doProc = item.do_proc;
    const icon = menuItemIconName(item);
    const label = opts.showGroup && groupTitle ? `[${groupTitle}] ${item.title}` : item.title;
    if (opts.iconOnly) {
      btn.className = opts.className || "menu-icon-item";
      btn.innerHTML = `${uiIcon(icon, 28)}<span>${escapeHtml(item.title)}</span>`;
      btn.title = item.title;
    } else {
      btn.innerHTML = `${uiIcon(icon, 14)}<span class="btn-label">${escapeHtml(label)}</span>`;
    }
    bindMenuItemOpen(btn, item.do_proc, item.title, !!opts.dblClick);
    return btn;
  }

  function renderMenuTree(nav) {
    nav.className = "menu-nav-tree";
    menuGroups.forEach((group) => {
      const gEl = document.createElement("div");
      gEl.className = "menu-tree-group";
      const title = document.createElement("div");
      title.className = "menu-tree-group-title";
      title.textContent = group.title;
      gEl.appendChild(title);
      group.items.forEach((item) => {
        const btn = createMenuItemButton(item, group.title, {
          className: "menu-item menu-tree-item btn-has-icon",
          dblClick: true,
        });
        gEl.appendChild(btn);
      });
      nav.appendChild(gEl);
    });
  }

  function renderMenuIconGrid(nav) {
    menuGroups.forEach((group) => {
      const gEl = document.createElement("div");
      gEl.className = "menu-group";
      const title = document.createElement("div");
      title.className = "menu-group-title";
      title.textContent = group.title;
      gEl.appendChild(title);
      const grid = document.createElement("div");
      grid.className = "menu-icon-grid";
      group.items.forEach((item) => {
        grid.appendChild(
          createMenuItemButton(item, group.title, { iconOnly: true, dblClick: true })
        );
      });
      gEl.appendChild(grid);
      nav.appendChild(gEl);
    });
  }

  function renderMenuList(nav) {
    menuGroups.forEach((group) => {
      group.items.forEach((item) => {
        nav.appendChild(
          createMenuItemButton(item, group.title, {
            className: "menu-item menu-list-item btn-has-icon",
            showGroup: true,
          })
        );
      });
    });
  }

  function renderMenuToolbox(nav) {
    nav.className = "menu-nav-toolbox";
    menuGroups.forEach((group, gi) => {
      const gEl = document.createElement("div");
      gEl.className = "menu-toolbox-group";
      const head = document.createElement("button");
      head.type = "button";
      head.className = "menu-toolbox-title";
      head.textContent = group.title;
      const body = document.createElement("div");
      body.className = "menu-toolbox-body" + (gi === 0 ? "" : " hidden");
      group.items.forEach((item) => {
        body.appendChild(
          createMenuItemButton(item, group.title, {
            className: "menu-item btn-has-icon",
          })
        );
      });
      head.addEventListener("click", () => {
        const hidden = body.classList.toggle("hidden");
        head.setAttribute("aria-expanded", hidden ? "false" : "true");
      });
      gEl.appendChild(head);
      gEl.appendChild(body);
      nav.appendChild(gEl);
    });
  }

  function renderMenuTabs(nav) {
    nav.className = "menu-nav-tabs";
    const bar = document.createElement("div");
    bar.className = "menu-tabs-bar";
    const panels = document.createElement("div");
    panels.className = "menu-tabs-panels";
    menuGroups.forEach((group, gi) => {
      const tabBtn = document.createElement("button");
      tabBtn.type = "button";
      tabBtn.className = "menu-tab-btn" + (gi === 0 ? " active" : "");
      tabBtn.textContent = group.title;
      tabBtn.dataset.menuTab = String(gi);
      const panel = document.createElement("div");
      panel.className = "menu-tabs-panel" + (gi === 0 ? "" : " hidden");
      panel.dataset.menuPanel = String(gi);
      group.items.forEach((item) => {
        panel.appendChild(
          createMenuItemButton(item, group.title, { className: "menu-item btn-has-icon" })
        );
      });
      tabBtn.addEventListener("click", () => {
        bar.querySelectorAll(".menu-tab-btn").forEach((b) => {
          b.classList.toggle("active", b.dataset.menuTab === String(gi));
        });
        panels.querySelectorAll(".menu-tabs-panel").forEach((p) => {
          p.classList.toggle("hidden", p.dataset.menuPanel !== String(gi));
        });
      });
      bar.appendChild(tabBtn);
      panels.appendChild(panel);
    });
    nav.appendChild(bar);
    nav.appendChild(panels);
  }

  function syncMenuModeSelect() {
    const sel = $("#menu-mode-select");
    if (sel) sel.value = loadMenuMode();
  }

  function renderMenu() {
    const nav = $("#menu-nav");
    nav.innerHTML = "";
    nav.className = "";
    const mode = loadMenuMode();
    syncMenuModeSelect();
    if (mode === "ICON_GRID") renderMenuIconGrid(nav);
    else if (mode === "LIST") renderMenuList(nav);
    else if (mode === "TOOLBOX") renderMenuToolbox(nav);
    else if (mode === "TABS") renderMenuTabs(nav);
    else renderMenuTree(nav);
  }

  function workTabId(doProc) {
    return `work-${doProc}`;
  }

  function detailTabId(workId, suffix) {
    return `detail-${workId}-${suffix}`;
  }

  async function openWorkTab(doProc, title) {
    const id = workTabId(doProc);
    if (!openTabs.find((x) => x.id === id)) {
      openTabs.push({
        type: "work",
        id,
        doProc,
        title,
        keyword: "",
        filtered: false,
        selectedRow: null,
        rows: [],
        physicalRows: [],
        fields: [],
        columns: [],
        formFields: [],
        formColumns: [],
        physicalFields: [],
        txFiles: [],
        printKeyColumn: null,
        menuTitle: title,
        columnWidths: {},
        workActions: mergeWorkActions({}, findMenuWorkActions(doProc)),
      });
    }
    const tab = openTabs.find((x) => x.id === id);
    if (tab) {
      tab.workActions = mergeWorkActions(findMenuWorkActions(doProc), tab.workActions);
      const menuWa = findMenuWorkActions(doProc);
      const tabWa = tab.workActions || {};
      const missingFlags =
        (isWorkFlagTrue(menuWa.need_attach) && !isWorkFlagTrue(tabWa.need_attach)) ||
        (isWorkFlagTrue(menuWa.need_other) && !isWorkFlagTrue(tabWa.need_other));
      if (!tab.rows.length || missingFlags) {
        await loadWorkData(tab, { reloadProgram: true });
      }
    }
    activeTabId = id;
    renderTabs();
  }

  async function loadWorkData(tab, opts = {}) {
    const asFilter = opts.asFilter === true;
    const reloadProgram = opts.reloadProgram === true;
    const data = await api(`/work/${encodeURIComponent(tab.doProc)}/rows`, {
      method: "POST",
      body: JSON.stringify({
        keyword: tab.keyword,
        as_filter: asFilter,
        limit: 500,
        reload_program: reloadProgram,
      }),
    });
    Object.assign(tab, {
      tableName: data.table_name,
      rows: data.rows,
      physicalRows: data.physical_rows || data.rows,
      fields: data.fields,
      columns: data.columns,
      formFields: data.form_fields || [],
      formColumns: data.form_columns || [],
      physicalFields: data.physical_fields || data.fields,
      txFiles: data.tx_files || [],
      printKeyColumn: data.print_doc_key_column,
      menuTitle: data.menu_title || tab.title,
      workActions: mergeWorkActions(
        findMenuWorkActions(tab.doProc),
        tab.workActions,
        data.work_actions || {}
      ),
      filtered: asFilter,
    });
    if (!asFilter && tab.keyword) {
      const kw = tab.keyword.toLowerCase();
      const idx = (tab.physicalRows || []).findIndex((row) =>
        row.some((c) => String(c).toLowerCase().includes(kw))
      );
      tab.selectedRow = idx >= 0 ? idx : tab.selectedRow;
    } else if (asFilter && tab.rows.length) {
      tab.selectedRow = 0;
    }
    initWorkColumnWidths(tab);
  }

  /** 對齊 Access/SQLite 布林（Y/1/-1/TRUE）與 JSON boolean。 */
  function isWorkFlagTrue(v) {
    if (v === true || v === 1 || v === -1) return true;
    if (typeof v === "string") {
      const s = v.trim().toUpperCase();
      return s === "Y" || s === "YES" || s === "TRUE" || s === "1" || s === "-1";
    }
    return false;
  }

  function findMenuWorkActions(doProc) {
    const key = String(doProc || "").trim().toUpperCase();
    for (const g of menuGroups) {
      for (const it of g.items || []) {
        if (String(it.do_proc || "").trim().toUpperCase() === key) {
          return {
            need_attach: it.need_attach,
            attach_path: it.attach_path || "",
            attach_key: it.attach_key || "",
            need_other: it.need_other,
            other_title: it.other_title || "",
          };
        }
      }
    }
    return {};
  }

  /** 合併選單 PROGRAM 與作業 API 的 NEED_ATTACH / NEED_OTHER 旗標。 */
  function mergeWorkActions(...sources) {
    const out = {
      need_attach: false,
      attach_path: "",
      attach_key: "",
      need_other: false,
      other_title: "",
    };
    for (const wa of sources) {
      if (!wa) continue;
      if (isWorkFlagTrue(wa.need_attach)) {
        out.need_attach = true;
        if ((wa.attach_path || "").trim()) out.attach_path = wa.attach_path.trim();
        if ((wa.attach_key || "").trim()) out.attach_key = wa.attach_key.trim();
      }
      if (isWorkFlagTrue(wa.need_other)) {
        out.need_other = true;
        if ((wa.other_title || "").trim()) out.other_title = wa.other_title.trim();
      }
    }
    return out;
  }

  function tabWorkActions(tab) {
    return mergeWorkActions(findMenuWorkActions(tab.doProc), tab.workActions || {});
  }

  function formatRecordNavLabel(total, current1based) {
    if (total <= 0) return "0/0";
    if (current1based == null) return `-/${total}`;
    return `${current1based}/${total}`;
  }

  function refreshWorkGridNavUi(page, tab) {
    if (!page) return;
    const total = tab.rows.length;
    const cur = tab.selectedRow != null && tab.selectedRow >= 0 && tab.selectedRow < total
      ? tab.selectedRow + 1
      : null;
    const navEl = $(".record-nav", page);
    if (navEl) navEl.textContent = formatRecordNavLabel(total, cur);

    const row = tab.selectedRow;
    const noSel = row == null || row < 0 || row >= total;
    const hasRows = total > 0;
    const setDisabled = (sel, disabled) => {
      const btn = page.querySelector(sel);
      if (btn) btn.disabled = disabled;
    };
    setDisabled('[data-nav="first"]', !hasRows || (!noSel && row <= 0));
    setDisabled('[data-nav="prev"]', !hasRows || noSel || row <= 0);
    setDisabled('[data-nav="next"]', !hasRows || noSel || row >= total - 1);
    setDisabled('[data-nav="last"]', !hasRows || (!noSel && row >= total - 1));
  }

  function scrollRowInContainer(container, row, opts = {}) {
    if (!container || !row) return;
    const headSel = opts.headSelector ?? "thead";
    const head = headSel ? container.querySelector(headSel) : null;
    const headH = head ? head.getBoundingClientRect().height : 0;
    const margin = opts.margin ?? 6;
    const hBar = Math.max(0, container.offsetHeight - container.clientHeight);

    const adjust = () => {
      const cRect = container.getBoundingClientRect();
      const rRect = row.getBoundingClientRect();
      const viewTop = cRect.top + headH + margin;
      const viewBottom = cRect.bottom - hBar - margin;
      if (rRect.top < viewTop) {
        container.scrollTop -= viewTop - rRect.top;
        return true;
      }
      if (rRect.bottom > viewBottom) {
        container.scrollTop += rRect.bottom - viewBottom;
        return true;
      }
      return false;
    };

    adjust();
    adjust();
  }

  function scrollWorkGridRowIntoView(tab, page) {
    page = page || document.querySelector(`.work-page[data-tab="${tab.id}"]`);
    if (!page || tab.selectedRow == null) return;
    const wrap = $(".work-table-wrap", page);
    const tr = page.querySelector(`tbody tr[data-row="${tab.selectedRow}"]`);
    if (!wrap || !tr) return;
    scrollRowInContainer(wrap, tr);
  }

  function selectWorkGridRow(tab, page, row, opts = {}) {
    const total = tab.rows.length;
    if (!total) {
      tab.selectedRow = null;
    } else if (row == null || row < 0 || row >= total) {
      return false;
    } else {
      tab.selectedRow = row;
    }
    $$(`.work-table tbody tr[data-row]`, page).forEach((tr) => {
      const ri = parseInt(tr.dataset.row, 10);
      tr.classList.toggle("selected", tab.selectedRow === ri);
    });
    refreshWorkGridNavUi(page, tab);
    if (opts.scroll !== false) scrollWorkGridRowIntoView(tab, page);
    if (opts.focus !== false) {
      const wrap = $(".work-table-wrap", page);
      if (wrap) wrap.focus({ preventScroll: true });
    }
    return true;
  }

  function navigateWorkGrid(tab, page, nav) {
    const n = tab.rows.length;
    if (!n) return;
    const row = tab.selectedRow;
    const noSel = row == null || row < 0 || row >= n;
    if (nav === "first") selectWorkGridRow(tab, page, 0);
    else if (nav === "last") selectWorkGridRow(tab, page, n - 1);
    else if (nav === "prev") {
      if (!noSel && row > 0) selectWorkGridRow(tab, page, row - 1);
    }     else if (nav === "next") {
      if (!noSel && row < n - 1) selectWorkGridRow(tab, page, row + 1);
    }
  }

  function charWidthPx(chars) {
    return Math.max(48, Math.round(chars * 9 + 20));
  }

  function gridCellAlignClass(meta) {
    return meta && meta.align === "right" ? " cell-align-right" : "";
  }

  function initWorkColumnWidths(tab) {
    if (!tab.columnWidths) tab.columnWidths = {};
    (tab.fields || []).forEach((field, i) => {
      if (tab.columnWidths[field] != null) return;
      const meta = (tab.columns || [])[i] || {};
      const title = meta.title || field;
      let maxChars = String(title).length;
      (tab.rows || []).slice(0, 80).forEach((row) => {
        maxChars = Math.max(maxChars, String(row[i] || "").length);
      });
      const wdict = meta.grid_width_chars || 0;
      if (wdict > 0) {
        tab.columnWidths[field] = charWidthPx(wdict);
      } else {
        tab.columnWidths[field] = charWidthPx(Math.min(Math.max(maxChars, 6), 80));
      }
    });
  }

  function workColWidthStyle(tab, field) {
    const w = tab.columnWidths && tab.columnWidths[field];
    if (!w) return "";
    return ` style="width:${w}px;min-width:${w}px;max-width:${w}px"`;
  }

  function initTxColumnWidths(txd) {
    if (!txd.columnWidths) txd.columnWidths = {};
    (txd.fields || []).forEach((field, i) => {
      if (txd.columnWidths[field] != null) return;
      const meta = (txd.columns || []).find((c) => c.name === field) || (txd.columns || [])[i] || {};
      const title = meta.title || field;
      let maxChars = String(title).length;
      (txd.rows || txd.physical_rows || []).slice(0, 80).forEach((row, ri) => {
        const prow = (txd.physical_rows || [])[ri];
        const pi = txd.physical_fields.indexOf(field);
        let val = "";
        if (Array.isArray(row) && i < row.length) {
          val = row[i] !== undefined ? row[i] : "";
        } else if (prow && pi >= 0) {
          val = prow[pi] !== undefined ? prow[pi] : "";
        }
        maxChars = Math.max(maxChars, String(val).length);
      });
      const wdict = meta.grid_width_chars || 0;
      if (wdict > 0) {
        txd.columnWidths[field] = charWidthPx(wdict);
      } else {
        txd.columnWidths[field] = charWidthPx(Math.min(Math.max(maxChars, 6), 80));
      }
    });
  }

  function txColWidthStyle(txd, field) {
    const w = txd.columnWidths && txd.columnWidths[field];
    if (!w) return "";
    return ` style="width:${w}px;min-width:${w}px;max-width:${w}px"`;
  }

  function bindWorkGridColumnResize(page, tab) {
    $$(".work-page .work-table:not(.tx-table) th[data-col] .col-resizer", page).forEach((resizer) => {
      resizer.addEventListener("mousedown", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const th = resizer.closest("th[data-col]");
        if (!th) return;
        const field = th.dataset.col;
        const startX = e.clientX;
        const startW = th.offsetWidth;
        document.body.classList.add("col-resizing");

        const onMove = (ev) => {
          const newW = Math.max(40, startW + (ev.clientX - startX));
          if (!tab.columnWidths) tab.columnWidths = {};
          tab.columnWidths[field] = newW;
          th.style.width = `${newW}px`;
          th.style.minWidth = `${newW}px`;
          th.style.maxWidth = `${newW}px`;
          const colIdx = tab.fields.indexOf(field);
          if (colIdx >= 0) {
            $$(`.work-page .work-table:not(.tx-table) tbody tr`, page).forEach((tr) => {
              const td = tr.children[colIdx];
              if (td) {
                td.style.width = `${newW}px`;
                td.style.minWidth = `${newW}px`;
                td.style.maxWidth = `${newW}px`;
              }
            });
          }
        };
        const onUp = () => {
          document.body.classList.remove("col-resizing");
          document.removeEventListener("mousemove", onMove);
          document.removeEventListener("mouseup", onUp);
        };
        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
      });
    });
  }

  function bindTxGridColumnResize(page, detail, tx) {
    const txd = detail.txData[tx];
    if (!txd) return;
    $$(`.tx-table[data-tx="${CSS.escape(tx)}"] th[data-col] .col-resizer`, page).forEach((resizer) => {
      resizer.addEventListener("mousedown", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const th = resizer.closest("th[data-col]");
        if (!th) return;
        const field = th.dataset.col;
        const startX = e.clientX;
        const startW = th.offsetWidth;
        document.body.classList.add("col-resizing");

        const onMove = (ev) => {
          const newW = Math.max(40, startW + (ev.clientX - startX));
          if (!txd.columnWidths) txd.columnWidths = {};
          txd.columnWidths[field] = newW;
          th.style.width = `${newW}px`;
          th.style.minWidth = `${newW}px`;
          th.style.maxWidth = `${newW}px`;
          const colIdx = txd.fields.indexOf(field);
          if (colIdx >= 0) {
            $$(`.tx-table[data-tx="${CSS.escape(tx)}"] tbody tr`, page).forEach((tr) => {
              const td = tr.children[colIdx];
              if (td) {
                td.style.width = `${newW}px`;
                td.style.minWidth = `${newW}px`;
                td.style.maxWidth = `${newW}px`;
              }
            });
          }
        };
        const onUp = () => {
          document.body.classList.remove("col-resizing");
          document.removeEventListener("mousemove", onMove);
          document.removeEventListener("mouseup", onUp);
        };
        document.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
      });
    });
  }

  function closeTab(id) {
    const tab = openTabs.find((x) => x.id === id);
    if (tab && tab.type === "work") {
      openTabs = openTabs.filter((x) => x.parentWorkId !== id && x.id !== id);
    } else {
      openTabs = openTabs.filter((x) => x.id !== id);
    }
    if (activeTabId === id) {
      activeTabId = openTabs.length ? openTabs[openTabs.length - 1].id : null;
    }
    renderTabs();
  }

  function getWorkTabForDetail(detailTab) {
    return openTabs.find((x) => x.id === detailTab.parentWorkId);
  }

  async function openDetailTab(workTab, mode, rowIndex) {
    const suffix = mode === "add" ? "new" : String(rowIndex);
    const id = detailTabId(workTab.id, suffix);
    if (openTabs.find((x) => x.id === id)) {
      activeTabId = id;
      renderTabs();
      return;
    }

    let formValues = {};
    let oldRow = [];
    if (mode === "add") {
      workTab.formFields.forEach((f) => {
        formValues[f] = "";
      });
    } else {
      oldRow = [...(workTab.physicalRows[rowIndex] || [])];
      try {
        const fv = await api(`/work/${encodeURIComponent(workTab.doProc)}/form-values`, {
          method: "POST",
          body: JSON.stringify({ old_row: oldRow }),
        });
        formValues = fv.values || {};
      } catch (_) {
        workTab.formFields.forEach((f) => {
          const fi = workTab.physicalFields.indexOf(f);
          formValues[f] = fi >= 0 && oldRow[fi] !== undefined ? oldRow[fi] : "";
        });
      }
    }

    const detail = {
      type: "detail",
      id,
      parentWorkId: workTab.id,
      doProc: workTab.doProc,
      title: workTab.menuTitle || workTab.title,
      mode,
      rowIndex,
      oldRow,
      formValues,
      formFields: [...workTab.formFields],
      formColumns: [...workTab.formColumns],
      txFiles: [...workTab.txFiles],
      txData: {},
    };

    if (workTab.txFiles.length) {
      for (const tx of workTab.txFiles) {
        try {
          const txd = await api(
            `/work/${encodeURIComponent(workTab.doProc)}/tx/${encodeURIComponent(tx)}/rows`,
            { method: "POST", body: JSON.stringify({ physical_row: oldRow }) }
          );
          detail.txData[tx] = normalizeTxData(txd);
        } catch (_) {
          detail.txData[tx] = normalizeTxData({
            tx_table: tx,
            fields: [],
            physical_fields: [],
            columns: [],
            physical_rows: [],
            rows: [],
            read_only: false,
          });
        }
      }
    }

    openTabs.push(detail);
    activeTabId = id;
    renderTabs();
  }

  async function buildFormDetailState(workTab, mode, rowIndex) {
    let formValues = {};
    let oldRow = [];
    if (mode === "add") {
      workTab.formFields.forEach((f) => {
        formValues[f] = "";
      });
    } else {
      oldRow = [...(workTab.physicalRows[rowIndex] || [])];
      try {
        const fv = await api(`/work/${encodeURIComponent(workTab.doProc)}/form-values`, {
          method: "POST",
          body: JSON.stringify({ old_row: oldRow }),
        });
        formValues = fv.values || {};
      } catch (_) {
        workTab.formFields.forEach((f) => {
          const fi = workTab.physicalFields.indexOf(f);
          formValues[f] = fi >= 0 && oldRow[fi] !== undefined ? oldRow[fi] : "";
        });
      }
    }

    const detail = {
      type: "detail",
      id: "form-modal",
      parentWorkId: workTab.id,
      doProc: workTab.doProc,
      title: workTab.menuTitle || workTab.title,
      mode,
      rowIndex,
      oldRow,
      formValues,
      formFields: [...workTab.formFields],
      formColumns: [...workTab.formColumns],
      txFiles: [...workTab.txFiles],
      txData: {},
      inModal: true,
    };

    if (workTab.txFiles.length && mode !== "add") {
      for (const tx of workTab.txFiles) {
        try {
          const txd = await api(
            `/work/${encodeURIComponent(workTab.doProc)}/tx/${encodeURIComponent(tx)}/rows`,
            { method: "POST", body: JSON.stringify({ physical_row: oldRow }) }
          );
          detail.txData[tx] = normalizeTxData(txd);
        } catch (_) {
          detail.txData[tx] = normalizeTxData({
            tx_table: tx,
            fields: [],
            physical_fields: [],
            columns: [],
            physical_rows: [],
            rows: [],
            read_only: false,
          });
        }
      }
    } else if (workTab.txFiles.length) {
      workTab.txFiles.forEach((tx) => {
        detail.txData[tx] = normalizeTxData({
          tx_table: tx,
          fields: [],
          physical_fields: [],
          columns: [],
          physical_rows: [],
          rows: [],
          read_only: false,
        });
      });
    }
    return detail;
  }

  function closeFormModal() {
    const el = $("#form-modal-overlay");
    if (el) el.remove();
    formModalState = null;
  }

  async function persistDetailRecord(detail, page) {
    collectTxPhysicalRowsFromPage(page, detail);
    const values = collectFormValues(page);
    if (detail.mode === "add" || detail.mode === "copy") {
      await api(`/work/${encodeURIComponent(detail.doProc)}/insert`, {
        method: "POST",
        body: JSON.stringify({ values }),
      });
    } else {
      await api(`/work/${encodeURIComponent(detail.doProc)}/update`, {
        method: "PUT",
        body: JSON.stringify({ values, old_row: detail.oldRow }),
      });
    }
    if (detail.txFiles.length) {
      for (const tx of detail.txFiles) {
        const txRows = detail.txData[tx]?.physical_rows || [];
        await api(
          `/work/${encodeURIComponent(detail.doProc)}/tx/${encodeURIComponent(tx)}/save`,
          {
            method: "PUT",
            body: JSON.stringify({
              physical_rows: txRows,
              master_form_values: values,
              master_row: detail.oldRow,
            }),
          }
        );
      }
    }
    const workTab = getWorkTabForDetail(detail);
    if (workTab) {
      await loadWorkData(workTab, { asFilter: workTab.filtered });
      activeTabId = workTab.id;
      renderTabs();
    }
  }

  async function openFormModal(workTab, mode, rowIndex) {
    const detail = await buildFormDetailState(workTab, mode, rowIndex);
    formModalState = detail;
    closeFormModal();
    const overlay = document.createElement("div");
    overlay.id = "form-modal-overlay";
    overlay.className = "form-modal-overlay";
    const headerTitle =
      detail.mode === "add" ? t("addTitle", detail.title) : t("editTitle", detail.title);
    overlay.innerHTML = `<div class="form-modal" role="dialog" aria-modal="true">
      <div class="form-modal-header"><h2>${escapeHtml(headerTitle)}</h2></div>
      <div class="form-modal-body">${renderDetailPage(detail)}</div>
    </div>`;
    document.body.appendChild(overlay);
    const page = overlay.querySelector(".detail-page");
    bindDetailPageEvents(detail, {
      onCancel: closeFormModal,
      onSaved: closeFormModal,
      rootPage: page,
    });
    bindDateFields(page);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeFormModal();
    });
  }

  function tabLabel(tab) {
    if (tab.type === "work") return tab.menuTitle || tab.title;
    const suffix = t("detailSuffix");
    return `${tab.title} — ${suffix}`;
  }

  function renderTabs() {
    const bar = $("#tabs-bar");
    const content = $("#tabs-content");
    bar.innerHTML = "";

    if (!openTabs.length) {
      content.innerHTML = `<div class="empty-state"><p>${t("emptyMenu")}</p></div>`;
      return;
    }

    openTabs.forEach((tab) => {
      const btn = document.createElement("button");
      btn.className = "tab-btn" + (tab.id === activeTabId ? " active" : "");
      btn.innerHTML = `<span>${escapeHtml(tabLabel(tab))}</span><span class="tab-close" data-close="${tab.id}">&times;</span>`;
      btn.addEventListener("click", (e) => {
        if (e.target.classList.contains("tab-close")) {
          e.stopPropagation();
          closeTab(tab.id);
        } else {
          activeTabId = tab.id;
          renderTabs();
        }
      });
      bar.appendChild(btn);
    });

    const active = openTabs.find((x) => x.id === activeTabId);
    if (!active) return;
    content.innerHTML = active.type === "work" ? renderWorkPage(active) : renderDetailPage(active);
    if (active.type === "work") {
      bindWorkPageEvents(active);
      const page = document.querySelector(`.work-page[data-tab="${active.id}"]`);
      if (page) {
        refreshWorkGridNavUi(page, active);
        requestAnimationFrame(() => scrollWorkGridRowIntoView(active, page));
      }
    } else bindDetailPageEvents(active);
    if (active.type === "detail") {
      const dp = document.querySelector(`.detail-page[data-tab="${active.id}"]`);
      bindDateFields(dp);
    }
  }

  function renderWorkPage(tab) {
    initWorkColumnWidths(tab);
    const colTitles = tab.columns.map((c) => c.title || c.name);
    const thead = tab.fields
      .map((f, i) => {
        const ws = workColWidthStyle(tab, f);
        return `<th data-col="${escapeHtml(f)}"${ws}><span class="th-text">${escapeHtml(colTitles[i] || f)}</span><span class="col-resizer" title="拖曳調整欄寬"></span></th>`;
      })
      .join("");
    const emptyCells = tab.fields
      .map((f) => {
        const ws = f ? workColWidthStyle(tab, f) : "";
        return `<td class="grid-pad-cell"${ws}>&nbsp;</td>`;
      })
      .join("");
    let tbody = "";
    if (tab.rows.length) {
      tbody = tab.rows
        .map((row, ri) => {
          const cells = row
            .map((v, ci) => {
              const field = tab.fields[ci];
              const meta = (tab.columns || [])[ci] || {};
              const ws = field ? workColWidthStyle(tab, field) : "";
              const cls = gridCellAlignClass(meta);
              return `<td class="${cls.trim()}"${ws}>${escapeHtml(v)}</td>`;
            })
            .join("");
          const sel = tab.selectedRow === ri ? " selected" : "";
          return `<tr data-row="${ri}" class="${sel.trim()}">${cells}</tr>`;
        })
        .join("");
      const padCount = Math.max(0, GRID_VISIBLE_ROWS - tab.rows.length);
      for (let i = 0; i < padCount; i++) {
        tbody += `<tr class="grid-pad-row" aria-hidden="true">${emptyCells}</tr>`;
      }
    } else {
      tbody = `<tr><td colspan="99" class="no-data">${t("noData")}</td></tr>`;
    }

    const cur =
      tab.selectedRow != null && tab.selectedRow >= 0 && tab.selectedRow < tab.rows.length
        ? tab.selectedRow + 1
        : null;
    const total = tab.rows.length;
    const navLabel = formatRecordNavLabel(total, cur);
    const totalRows = tab.rows.length;
    const row = tab.selectedRow;
    const noSel = row == null || row < 0 || row >= totalRows;
    const hasRows = totalRows > 0;
    const disFirst = !hasRows || (!noSel && row <= 0);
    const disPrev = !hasRows || noSel || row <= 0;
    const disNext = !hasRows || noSel || row >= totalRows - 1;
    const disLast = !hasRows || (!noSel && row >= totalRows - 1);
    const wa = tabWorkActions(tab);
    const attachBtn = isWorkFlagTrue(wa.need_attach)
      ? iconBtn(t("attachment"), "attachment", "btn action-btn", 'data-act="attachment"')
      : "";
    const otherTitle = (wa.other_title || "").trim() || t("otherDefault");
    const otherBtn = isWorkFlagTrue(wa.need_other)
      ? iconBtn(otherTitle, "other", "btn action-btn", 'data-act="other"')
      : "";

    return `
      <div class="work-page" data-tab="${tab.id}">
        <div class="search-row">
          <label class="search-label">${t("searchLabel")}</label>
          <input type="text" class="search-input" value="${escapeHtml(tab.keyword)}">
        </div>
        <div class="action-bar">
          ${iconBtn(t("search"), "search", "btn action-btn", 'data-act="search"')}
          ${iconBtn(t("filter"), "filter", "btn action-btn", 'data-act="filter"')}
          ${iconBtn(t("add"), "add", "btn action-btn", 'data-act="add"')}
          ${iconBtn(t("edit"), "edit", "btn action-btn", 'data-act="edit"')}
          ${iconBtn(t("del"), "delete", "btn action-btn", 'data-act="delete"')}
          ${iconBtn(t("copy"), "copy", "btn action-btn", 'data-act="copy"')}
          ${iconBtn(t("print"), "print", "btn action-btn", 'data-act="print"')}
          ${attachBtn}
          ${otherBtn}
          ${iconBtn(t("exit"), "exit", "btn action-btn", 'data-act="exit"')}
        </div>
        <div class="work-table-wrap grid-focus-target work-grid-20-rows" tabindex="0">
          <table class="work-table">
            <thead><tr>${thead}</tr></thead>
            <tbody>${tbody}</tbody>
          </table>
        </div>
        <div class="nav-row">
          ${iconBtnOnly(t("navFirst"), "nav-first", "btn nav-btn", `data-nav="first"${disFirst ? " disabled" : ""}`)}
          ${iconBtnOnly(t("navPrev"), "nav-prev", "btn nav-btn", `data-nav="prev"${disPrev ? " disabled" : ""}`)}
          ${iconBtnOnly(t("navNext"), "nav-next", "btn nav-btn", `data-nav="next"${disNext ? " disabled" : ""}`)}
          ${iconBtnOnly(t("navLast"), "nav-last", "btn nav-btn", `data-nav="last"${disLast ? " disabled" : ""}`)}
          <span class="record-nav">${navLabel}</span>
        </div>
      </div>`;
  }

  function isLongTextField(meta) {
    const dt = (meta.data_type || "").toUpperCase();
    const name = (meta.name || "").toLowerCase();
    if (/note|remark|memo|備註|說明/.test(name)) return true;
    if (!dt) return false;
    if (dt === "MEMO" || dt === "LONGTEXT" || dt === "NTEXT") return true;
    return dt.includes("MEMO");
  }

  function isDateField(meta) {
    const dt = (meta.data_type || "").toUpperCase();
    return dt === "D" || dt === "DATE" || (meta.data_format || "").includes("/");
  }

  function isBoolField(meta) {
    const dt = (meta.data_type || "").toUpperCase();
    return dt === "B" || dt === "BOOLEAN";
  }

  function renderFormField(meta, value) {
    const name = meta.name;
    const title = meta.title || name;
    let inputHtml;
    if (isBoolField(meta)) {
      const y = value === "Y" || value === "y" || value === "1" || value === "-1";
      inputHtml = `<select name="${escapeHtml(name)}" data-field="${escapeHtml(name)}">
        <option value="Y" ${y ? "selected" : ""}>Y</option>
        <option value="N" ${!y ? "selected" : ""}>N</option>
      </select>`;
    } else if (isLongTextField(meta)) {
      inputHtml = `<textarea name="${escapeHtml(name)}" data-field="${escapeHtml(name)}" rows="3">${escapeHtml(value)}</textarea>`;
    } else if (isDateField(meta)) {
      const fmt = meta.data_format || "yyyy/MM/dd";
      const val = normalizeAppDateText(value);
      inputHtml = `<div class="date-field-wrap">
        <input type="text" class="app-date-input" name="${escapeHtml(name)}" data-field="${escapeHtml(name)}" value="${escapeHtml(val)}" placeholder="${escapeHtml(fmt)}">
        <button type="button" class="btn secondary date-pick-btn btn-icon-only" data-date-for="${escapeHtml(name)}" title="${escapeHtml(t("printDatePickBtn"))}">${uiIcon("view-calendar", 14)}</button>
      </div>`;
    } else {
      const cls = meta.data_type === "N" || meta.data_type === "NUMERIC" ? " num-field" : "";
      inputHtml = `<input type="text" class="${cls.trim()}" name="${escapeHtml(name)}" data-field="${escapeHtml(name)}" value="${escapeHtml(value)}">`;
    }
    return `<div class="form-field ${isLongTextField(meta) ? "form-field-wide" : ""}">
      <label>${escapeHtml(title)}:</label>${inputHtml}
    </div>`;
  }

  function openAppDatePicker(targetEl, onChange) {
    if (!targetEl) return;
    const picker = document.createElement("input");
    picker.type = "date";
    picker.style.position = "fixed";
    picker.style.left = "-9999px";
    picker.style.opacity = "0";
    document.body.appendChild(picker);
    const parsed = parseAppDate(normalizeAppDateText(targetEl.value));
    if (parsed) {
      picker.value = `${parsed.y}-${String(parsed.mo).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
    }
    const cleanup = () => picker.remove();
    picker.addEventListener("change", () => {
      if (picker.value) {
        const [y, mo, d] = picker.value.split("-").map((x) => parseInt(x, 10));
        targetEl.value = `${y}/${String(mo).padStart(2, "0")}/${String(d).padStart(2, "0")}`;
        if (onChange) onChange();
      }
      cleanup();
    });
    picker.addEventListener("blur", cleanup, { once: true });
    if (typeof picker.showPicker === "function") picker.showPicker();
    else picker.click();
  }

  function bindDateFields(root, onChange) {
    if (!root) return;
    root.querySelectorAll(".app-date-input").forEach((inp) => {
      inp.addEventListener("blur", () => {
        inp.value = normalizeAppDateText(inp.value);
      });
    });
    root.querySelectorAll(".date-pick-btn[data-date-for]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const name = btn.dataset.dateFor;
        const inp = root.querySelector(`[data-field="${CSS.escape(name)}"]`);
        openAppDatePicker(inp, onChange);
      });
    });
  }

  function normalizeTxData(txd) {
    txd.physical_rows = (txd.physical_rows || []).map((r) => [...r]);
    txd.physical_fields = txd.physical_fields || [];
    txd.fields = txd.fields || [];
    txd.columns = txd.columns || [];
    txd.selectedRow = txd.selectedRow != null ? txd.selectedRow : null;
    txd.keyword = txd.keyword || "";
    txd.columnWidths = txd.columnWidths || {};
    if (!txd.rows || !txd.rows.length) {
      syncTxDisplayRows(txd);
    }
    return txd;
  }

  function syncTxDisplayRows(txd) {
    txd.rows = txd.physical_rows.map((prow) =>
      txd.fields.map((f) => {
        const pi = txd.physical_fields.indexOf(f);
        return pi >= 0 && prow[pi] !== undefined ? prow[pi] : "";
      })
    );
  }

  function collectFormValues(page) {
    const values = {};
    $$("[data-field]", page).forEach((el) => {
      values[el.dataset.field] = el.value;
    });
    return values;
  }

  function resolveMasterKeyForTx(detail, formValues) {
    const workTab = getWorkTabForDetail(detail);
    const printKey = workTab && workTab.printKeyColumn;
    if (printKey && (formValues[printKey] || "").trim()) {
      return { col: printKey, val: formValues[printKey].trim() };
    }
    for (const f of detail.formFields) {
      if (f.toUpperCase() === "TX_KEY" && (formValues[f] || "").trim()) {
        return { col: f, val: formValues[f].trim() };
      }
    }
    return { col: null, val: null };
  }

  function txKeyColOnTable(txd, masterKeyCol) {
    if (masterKeyCol) {
      const c = txd.physical_fields.find((f) => f.toUpperCase() === masterKeyCol.toUpperCase());
      if (c) return c;
    }
    return (
      txd.physical_fields.find((f) => f.toUpperCase() === "TX_KEY") ||
      txd.filter_column ||
      null
    );
  }

  function createEmptyTxRow(txd, keyCol, keyVal) {
    const row = txd.physical_fields.map(() => "");
    if (keyCol && keyVal) {
      const idx = txd.physical_fields.findIndex((f) => f.toUpperCase() === keyCol.toUpperCase());
      if (idx >= 0) row[idx] = keyVal;
    }
    return row;
  }

  function collectTxPhysicalRowsFromPage(page, detail) {
    const result = {};
    for (const tx of detail.txFiles) {
      const txd = detail.txData[tx];
      if (!txd) continue;
      const rows = [];
      $$(`.tx-table[data-tx="${CSS.escape(tx)}"] tbody tr[data-tx-row]`, page).forEach((tr) => {
        const ri = parseInt(tr.dataset.txRow, 10);
        const prow = txd.physical_fields.map((_, i) => {
          const inp = tr.querySelector(`.tx-cell[data-phys-idx="${i}"]`);
          if (inp) return inp.value;
          const existing = txd.physical_rows[ri];
          return existing && existing[i] !== undefined ? existing[i] : "";
        });
        rows.push(prow);
      });
      txd.physical_rows = rows;
      syncTxDisplayRows(txd);
      result[tx] = rows;
    }
    return result;
  }

  function updateTxSelectionUi(page, tx, txd) {
    const total = (txd.physical_rows || []).length;
    const row = txd.selectedRow;
    const noSel = row == null || row < 0 || row >= total;
    const cur = !noSel ? row + 1 : null;
    $$(`.tx-table[data-tx="${CSS.escape(tx)}"] tbody tr[data-tx-row]`, page).forEach((tr) => {
      const ri = parseInt(tr.dataset.txRow, 10);
      tr.classList.toggle("selected", txd.selectedRow === ri);
    });
    const navEl = page.querySelector(`.tx-record-nav[data-tx="${CSS.escape(tx)}"]`);
    if (navEl) navEl.textContent = formatRecordNavLabel(total, cur);
    const hasRows = total > 0;
    ["first", "prev", "next", "last"].forEach((nav) => {
      const btn = page.querySelector(`.tx-nav[data-tx="${CSS.escape(tx)}"][data-nav="${nav}"]`);
      if (!btn) return;
      if (nav === "first") btn.disabled = !hasRows || (!noSel && row <= 0);
      else if (nav === "prev") btn.disabled = !hasRows || noSel || row <= 0;
      else if (nav === "next") btn.disabled = !hasRows || noSel || row >= total - 1;
      else if (nav === "last") btn.disabled = !hasRows || (!noSel && row >= total - 1);
    });
  }

  function scrollTxRowIntoView(page, tx, txd) {
    if (txd.selectedRow == null) return;
    const wrap = page.querySelector(`.tx-table[data-tx="${CSS.escape(tx)}"]`)?.closest(".tx-table-wrap");
    const tr = page.querySelector(`.tx-table[data-tx="${CSS.escape(tx)}"] tr[data-tx-row="${txd.selectedRow}"]`);
    if (!wrap || !tr) return;
    scrollRowInContainer(wrap, tr);
  }

  function selectTxRow(page, detail, tx, row, opts = {}) {
    const txd = detail.txData[tx];
    if (!txd) return false;
    collectTxPhysicalRowsFromPage(page, detail);
    const total = txd.physical_rows.length;
    if (!total) {
      txd.selectedRow = null;
    } else if (row == null || row < 0 || row >= total) {
      return false;
    } else {
      txd.selectedRow = row;
    }
    updateTxSelectionUi(page, tx, txd);
    if (opts.scroll !== false) scrollTxRowIntoView(page, tx, txd);
    return true;
  }

  function navigateTxGrid(page, detail, tx, nav) {
    const txd = detail.txData[tx];
    if (!txd || !txd.physical_rows.length) return;
    collectTxPhysicalRowsFromPage(page, detail);
    const n = txd.physical_rows.length;
    const row = txd.selectedRow;
    const noSel = row == null || row < 0 || row >= n;
    if (nav === "first") selectTxRow(page, detail, tx, 0);
    else if (nav === "last") selectTxRow(page, detail, tx, n - 1);
    else if (nav === "prev" && !noSel && row > 0) selectTxRow(page, detail, tx, row - 1);
    else if (nav === "next" && !noSel && row < n - 1) selectTxRow(page, detail, tx, row + 1);
  }

  function focusTxCell(page, detail, tx, row, col) {
    const tr = page.querySelector(
      `.tx-table[data-tx="${CSS.escape(tx)}"] tr[data-tx-row="${row}"]`
    );
    if (!tr) return false;
    const cells = [...tr.querySelectorAll(".tx-cell")];
    const el = cells[col];
    if (!el) return false;
    collectTxPhysicalRowsFromPage(page, detail);
    const txd = detail.txData[tx];
    if (txd) {
      txd.selectedRow = row;
      updateTxSelectionUi(page, tx, txd);
    }
    el.focus();
    el.select?.();
    return true;
  }

  function bindTxCellInputs(page, detail) {
    $$(".tx-cell", page).forEach((inp) => {
      inp.addEventListener("mousedown", (e) => e.stopPropagation());
      inp.addEventListener("click", (e) => e.stopPropagation());
      inp.addEventListener("dblclick", (e) => e.stopPropagation());
      inp.addEventListener("focus", (e) => {
        e.stopPropagation();
        if (inp.dataset.raw != null) {
          inp.value = inp.dataset.raw;
        }
        const tr = inp.closest("tr[data-tx-row]");
        if (!tr) return;
        const tx = tr.dataset.tx;
        const txd = detail.txData[tx];
        if (!txd) return;
        collectTxPhysicalRowsFromPage(page, detail);
        txd.selectedRow = parseInt(tr.dataset.txRow, 10);
        updateTxSelectionUi(page, tx, txd);
      });
      inp.addEventListener("keydown", (e) => {
        if (e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) return;
        const tr = inp.closest("tr[data-tx-row]");
        if (!tr) return;
        const tx = tr.dataset.tx;
        const txd = detail.txData[tx];
        if (!txd) return;
        const row = parseInt(tr.dataset.txRow, 10);
        const cells = [...tr.querySelectorAll(".tx-cell")];
        const col = cells.indexOf(inp);
        if (col < 0) return;
        const ncols = cells.length;
        const nrows = (txd.physical_rows || []).length;

        if (e.key === "Enter") {
          e.preventDefault();
          let nr = row;
          let nc = col + 1;
          if (nc >= ncols) {
            nc = 0;
            nr += 1;
          }
          if (nr >= nrows) {
            collectTxPhysicalRowsFromPage(page, detail);
            inp.blur();
            return;
          }
          focusTxCell(page, detail, tx, nr, nc);
          return;
        }

        const moves = {
          ArrowUp: [-1, 0],
          ArrowDown: [1, 0],
          ArrowLeft: [0, -1],
          ArrowRight: [0, 1],
        };
        const delta = moves[e.key];
        if (!delta) return;
        e.preventDefault();
        const nr = row + delta[0];
        const nc = col + delta[1];
        if (nr < 0 || nr >= nrows || nc < 0 || nc >= ncols) {
          collectTxPhysicalRowsFromPage(page, detail);
          return;
        }
        focusTxCell(page, detail, tx, nr, nc);
      });
    });
  }

  function renderTxPanel(detail, tx, index, opts = {}) {
    const embedded = opts.embedded === true;
    const txd = detail.txData[tx] || normalizeTxData({ tx_table: tx, fields: [], physical_fields: [], physical_rows: [] });
    initTxColumnWidths(txd);
    const cols = txd.columns || [];
    const thead = (txd.fields || [])
      .map((f, j) => {
        const ws = txColWidthStyle(txd, f);
        return `<th data-col="${escapeHtml(f)}"${ws}><span class="th-text">${escapeHtml((cols[j] && cols[j].title) || f)}</span><span class="col-resizer" title="拖曳調整欄寬"></span></th>`;
      })
      .join("");

    const tbody = (txd.physical_rows || []).length
      ? txd.physical_rows
          .map((prow, ri) => {
            const cells = (txd.fields || []).map((f, j) => {
              const pi = txd.physical_fields.indexOf(f);
              const rawVal = pi >= 0 && prow[pi] !== undefined ? prow[pi] : "";
              const displayVal =
                txd.rows && txd.rows[ri] && txd.rows[ri][j] !== undefined
                  ? txd.rows[ri][j]
                  : rawVal;
              const meta = cols.find((c) => c.name === f) || cols[j] || {};
              const alignCls = gridCellAlignClass(meta) ? " num-field" : "";
              const ws = txColWidthStyle(txd, f);
              return `<td${ws}><input class="tx-cell${alignCls}" type="text" data-phys-idx="${pi}" data-raw="${escapeHtml(String(rawVal))}" value="${escapeHtml(String(displayVal))}"></td>`;
            });
            const sel = txd.selectedRow === ri ? " selected" : "";
            return `<tr data-tx-row="${ri}" data-tx="${escapeHtml(tx)}" class="${sel.trim()}">${cells.join("")}</tr>`;
          })
          .join("")
      : `<tr><td colspan="99" class="no-data">${t("noData")}</td></tr>`;

    const cur =
      txd.selectedRow != null && txd.selectedRow >= 0 && txd.selectedRow < (txd.physical_rows || []).length
        ? txd.selectedRow + 1
        : null;
    const total = (txd.physical_rows || []).length;
    const navLabel = formatRecordNavLabel(total, cur);
    const tabLabel = detail.txFiles.length > 1 ? `${t("formDetail")} - ${index + 1}` : t("formDetail");
    const hasFields = (txd.fields || []).length > 0;

    const inner = `<div class="tx-toolbar">
        <div class="tx-nav-group">
          ${iconBtnOnly(t("navFirst"), "nav-first", "btn nav-btn tx-nav", `data-tx="${escapeHtml(tx)}" data-nav="first"`)}
          ${iconBtnOnly(t("navPrev"), "nav-prev", "btn nav-btn tx-nav", `data-tx="${escapeHtml(tx)}" data-nav="prev"`)}
          ${iconBtnOnly(t("navNext"), "nav-next", "btn nav-btn tx-nav", `data-tx="${escapeHtml(tx)}" data-nav="next"`)}
          ${iconBtnOnly(t("navLast"), "nav-last", "btn nav-btn tx-nav", `data-tx="${escapeHtml(tx)}" data-nav="last"`)}
          <span class="record-nav tx-record-nav" data-tx="${escapeHtml(tx)}">${navLabel}</span>
        </div>
        <div class="tx-crud-group">
          ${iconBtn(t("add"), "add", "btn action-btn tx-act", `data-tx="${escapeHtml(tx)}" data-tx-act="add"`)}
          ${iconBtn(t("edit"), "edit", "btn action-btn tx-act", `data-tx="${escapeHtml(tx)}" data-tx-act="edit"`)}
          ${iconBtn(t("del"), "delete", "btn action-btn tx-act", `data-tx="${escapeHtml(tx)}" data-tx-act="delete"`)}
          ${iconBtn(t("copy"), "copy", "btn action-btn tx-act", `data-tx="${escapeHtml(tx)}" data-tx-act="copy"`)}
        </div>
        <div class="tx-search-group">
          <label class="search-label">${t("searchLabel")}</label>
          <input type="text" class="tx-search-input" data-tx="${escapeHtml(tx)}" value="${escapeHtml(txd.keyword)}">
          ${iconBtn(t("search"), "search", "btn action-btn tx-act", `data-tx="${escapeHtml(tx)}" data-tx-act="search"`)}
        </div>
      </div>
      <div class="work-table-wrap tx-table-wrap">
        <table class="work-table tx-table" data-tx="${escapeHtml(tx)}">
          <thead><tr>${hasFields ? thead : `<th>${t("noData")}</th>`}</tr></thead>
          <tbody>${tbody}</tbody>
        </table>
      </div>`;

    if (embedded) return inner;

    return `<div class="tx-tab-panel" data-tx-panel="${escapeHtml(tx)}">
      <div class="tx-tab-title">${escapeHtml(tabLabel)} (${escapeHtml(tx)})</div>
      ${inner}
    </div>`;
  }

  function buildFormFieldMeta(detail) {
    const byName = new Map();
    (detail.formColumns || []).forEach((m) => byName.set(m.name, m));
    return (detail.formFields || []).map((name) => byName.get(name) || { name, title: name, edit_tab: "" });
  }

  function formDataTabTitle(base, idx1, totalTabs) {
    const b = (base || "").trim();
    if (currentLang === "ENG") {
      return totalTabs <= 1 ? `${b} Data` : `${b} Data - ${idx1}`;
    }
    return totalTabs <= 1 ? `${b} ${t("formData")}` : `${b} ${t("formData")} - ${idx1}`;
  }

  function detailTabTitle(base, idx1, totalTabs) {
    const b = (base || "").trim();
    if (currentLang === "ENG") {
      return totalTabs <= 1 ? `${b} Detail` : `${b} Detail - ${idx1}`;
    }
    return totalTabs <= 1 ? `${b} ${t("formDetail")}` : `${b} ${t("formDetail")} - ${idx1}`;
  }

  function splitFormFieldPages(detail) {
    const metaList = buildFormFieldMeta(detail);
    const fieldsPerPage = 30;
    const groups = new Map();
    const ungrouped = [];

    metaList.forEach((meta) => {
      const tabKey = (meta.edit_tab || "").trim();
      if (tabKey) {
        if (!groups.has(tabKey)) groups.set(tabKey, []);
        groups.get(tabKey).push(meta);
      } else {
        ungrouped.push(meta);
      }
    });

    let chunks = [];
    if (groups.size > 0) {
      groups.forEach((fields) => {
        if (fields.length) chunks.push(fields);
      });
      for (let i = 0; i < ungrouped.length; i += fieldsPerPage) {
        chunks.push(ungrouped.slice(i, i + fieldsPerPage));
      }
    } else {
      for (let i = 0; i < metaList.length; i += fieldsPerPage) {
        chunks.push(metaList.slice(i, i + fieldsPerPage));
      }
    }
    if (!chunks.length) chunks.push([]);

    const base = detail.title || "";
    const total = chunks.length;
    return chunks.map((fields, i) => ({
      id: String(i),
      title: formDataTabTitle(base, i + 1, total),
      fields,
    }));
  }

  function renderFormTabWidget(detail) {
    const pages = splitFormFieldPages(detail);
    const tabButtons = pages
      .map(
        (p, i) =>
          `<button type="button" class="inner-tab-btn${i === 0 ? " active" : ""}" data-form-tab="${p.id}">${escapeHtml(p.title)}</button>`
      )
      .join("");
    const tabPanels = pages
      .map(
        (p, i) => `<div class="form-tab-panel${i === 0 ? "" : " hidden"}" data-form-panel="${p.id}">
          <div class="form-grid">${p.fields.map((m) => renderFormField(m, detail.formValues[m.name] || "")).join("")}</div>
        </div>`
      )
      .join("");

    return `<div class="form-tab-widget">
      <div class="inner-tab-bar form-inner-tab-bar">${tabButtons}</div>
      <div class="form-tab-panels">${tabPanels}</div>
    </div>`;
  }

  function renderTxTabWidget(detail) {
    if (!detail.txFiles.length) return "";
    const base = detail.title || "";
    const total = detail.txFiles.length;
    const tabButtons = detail.txFiles
      .map(
        (tx, i) =>
          `<button type="button" class="inner-tab-btn${i === 0 ? " active" : ""}" data-tx-tab="${escapeHtml(tx)}">${escapeHtml(detailTabTitle(base, i + 1, total))}</button>`
      )
      .join("");
    const tabPanels = detail.txFiles
      .map((tx, i) => {
        const body = renderTxPanel(detail, tx, i, { embedded: true });
        return `<div class="tx-tab-panel${i === 0 ? "" : " hidden"}" data-tx-panel="${escapeHtml(tx)}">${body}</div>`;
      })
      .join("");

    return `<div class="tx-section"><div class="tx-tab-widget">
      <div class="inner-tab-bar tx-inner-tab-bar">${tabButtons}</div>
      <div class="tx-tab-panels">${tabPanels}</div>
    </div></div>`;
  }

  function activateFormTabForElement(page, el) {
    if (!el) return;
    const panel = el.closest(".form-tab-panel[data-form-panel]");
    if (!panel) return;
    if (!panel.classList.contains("hidden")) return;
    const id = panel.dataset.formPanel;
    const btn = page.querySelector(`.form-inner-tab-bar .inner-tab-btn[data-form-tab="${CSS.escape(id)}"]`);
    if (btn) btn.click();
  }

  function activateTxTabForElement(page, el) {
    if (!el) return;
    const panel = el.closest(".tx-tab-panel[data-tx-panel]");
    if (!panel || !panel.classList.contains("hidden")) return;
    const tx = panel.dataset.txPanel;
    const btn = page.querySelector(`.tx-inner-tab-bar .inner-tab-btn[data-tx-tab="${CSS.escape(tx)}"]`);
    if (btn) btn.click();
  }

  function bindFormTabEvents(page) {
    $$(".form-inner-tab-bar .inner-tab-btn[data-form-tab]", page).forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.formTab;
        $$(".form-inner-tab-bar .inner-tab-btn[data-form-tab]", page).forEach((b) => {
          b.classList.toggle("active", b.dataset.formTab === id);
        });
        $$(".form-tab-panels .form-tab-panel[data-form-panel]", page).forEach((p) => {
          p.classList.toggle("hidden", p.dataset.formPanel !== id);
        });
      });
    });
  }

  function bindTxTabEvents(page, detail) {
    $$(".tx-inner-tab-bar .inner-tab-btn[data-tx-tab]", page).forEach((btn) => {
      btn.addEventListener("click", () => {
        const tx = btn.dataset.txTab;
        $$(".tx-inner-tab-bar .inner-tab-btn[data-tx-tab]", page).forEach((b) => {
          b.classList.toggle("active", b.dataset.txTab === tx);
        });
        $$(".tx-tab-panels .tx-tab-panel[data-tx-panel]", page).forEach((p) => {
          p.classList.toggle("hidden", p.dataset.txPanel !== tx);
        });
        const txd = detail.txData[tx];
        if (txd) updateTxSelectionUi(page, tx, txd);
      });
    });
  }

  function renderDetailPage(detail) {
    const formHtml = renderFormTabWidget(detail);
    const txHtml = renderTxTabWidget(detail);

    const headerTitle =
      detail.mode === "add" ? t("addTitle", detail.title) : t("editTitle", detail.title);

    return `
      <div class="detail-page" data-tab="${detail.id}">
        <h2 class="detail-header">${escapeHtml(headerTitle)}</h2>
        <div class="detail-split">
          <div class="detail-form-area">${formHtml}</div>
          ${txHtml}
        </div>
        <div class="detail-actions">
          ${iconBtn(t("save"), "save", "btn primary", 'data-act="save"')}
          ${iconBtn(t("cancel"), "cancel", "btn secondary", 'data-act="cancel"')}
        </div>
        <p class="error detail-error hidden"></p>
      </div>`;
  }

  function bindWorkPageEvents(tab) {
    const page = $(`.work-page[data-tab="${tab.id}"]`);
    if (!page) return;

    bindWorkGridColumnResize(page, tab);

    const searchInput = $(".search-input", page);
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") doSearch(tab, page);
    });

    $$(".action-btn", page).forEach((btn) => {
      btn.addEventListener("click", () => {
        const act = btn.dataset.act;
        if (act === "search") doSearch(tab, page);
        else if (act === "filter") doFilter(tab, page);
        else if (act === "add") openFormModal(tab, "add", null);
        else if (act === "edit") {
          if (tab.selectedRow == null) {
            alert(t("selectRow"));
            return;
          }
          openFormModal(tab, "edit", tab.selectedRow);
        } else if (act === "copy") {
          if (tab.selectedRow == null) {
            alert(t("selectRow"));
            return;
          }
          openFormModal(tab, "copy", tab.selectedRow);
        } else if (act === "delete") doDelete(tab);
        else if (act === "print") doPrint(tab);
        else if (act === "attachment") doAttachment(tab);
        else if (act === "other") doOther(tab);
        else if (act === "exit") closeTab(tab.id);
      });
    });

    $$("[data-nav]", page).forEach((btn) => {
      btn.addEventListener("click", () => {
        if (btn.disabled) return;
        navigateWorkGrid(tab, page, btn.dataset.nav);
      });
    });

    const gridWrap = $(".work-table-wrap", page);
    if (gridWrap) {
      gridWrap.addEventListener("click", () => gridWrap.focus({ preventScroll: true }));
    }

    $$("tbody tr[data-row]", page).forEach((tr) => {
      tr.addEventListener("click", () => {
        selectWorkGridRow(tab, page, parseInt(tr.dataset.row, 10));
      });
      tr.addEventListener("dblclick", () => {
        const ri = parseInt(tr.dataset.row, 10);
        selectWorkGridRow(tab, page, ri, { scroll: false });
        openDetailTab(tab, "edit", ri);
      });
    });

    page.addEventListener("keydown", (e) => {
      if (e.target.closest("input, textarea, select, button")) return;
      const gridFocused = document.activeElement === gridWrap || gridWrap?.contains(document.activeElement);
      const n = tab.rows.length;
      if (n && gridFocused && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
        e.preventDefault();
        const row = tab.selectedRow;
        const noSel = row == null || row < 0 || row >= n;
        if (e.key === "ArrowDown") {
          if (noSel) selectWorkGridRow(tab, page, 0);
          else if (row < n - 1) selectWorkGridRow(tab, page, row + 1);
        } else if (!noSel && row > 0) {
          selectWorkGridRow(tab, page, row - 1);
        }
        return;
      }
      if (e.key === "Enter" && tab.selectedRow != null) {
        e.preventDefault();
        openDetailTab(tab, "edit", tab.selectedRow);
      }
    });
    page.setAttribute("tabindex", "-1");
  }

  async function doSearch(tab, page) {
    tab.keyword = $(".search-input", page).value.trim();
    tab.filtered = false;
    await loadWorkData(tab, { asFilter: false });
    renderTabs();
  }

  function resolveAttachmentPath(tab) {
    const wa = tabWorkActions(tab);
    let template = (wa.attach_path || "").trim() || "ATTACH";
    let keyVal = "";
    const row =
      tab.selectedRow != null && tab.physicalRows && tab.physicalRows[tab.selectedRow]
        ? tab.physicalRows[tab.selectedRow]
        : null;
    const keyCandidates = [tab.printKeyColumn, "TX_KEY", "ID"].filter(Boolean);
    const phys = tab.physicalFields || [];
    if (row) {
      for (const k of keyCandidates) {
        const idx = phys.findIndex((n) => String(n).toUpperCase() === String(k).toUpperCase());
        if (idx >= 0 && row[idx]) {
          keyVal = String(row[idx]).trim();
          if (keyVal) break;
        }
      }
    }
    return template
      .replace(/\{KEY\}/g, keyVal)
      .replace(/\{CO_KEY\}/g, currentUser?.company_key || "")
      .replace(/\{DO_PROC\}/g, tab.doProc || "")
      .replace(/\{TABLE\}/g, tab.tableName || "");
  }

  function closeAttachModal() {
    const el = $("#attach-modal-overlay");
    if (el) el.remove();
    attachModalState = null;
  }

  async function showAttachmentPreview(file) {
    const preview = $("#attach-preview");
    if (!preview || !file) return;
    preview.innerHTML = `<p>...</p>`;
    try {
      const res = await fetch(
        `/api/attachments/file?path=${encodeURIComponent(file.path)}`,
        { headers: token ? { Authorization: `Bearer ${token}` } : {} }
      );
      if (!res.ok) throw new Error(t("attachSelectRow"));
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      if (file.kind === "pdf") {
        preview.innerHTML = `<iframe src="${url}" title="${escapeHtml(file.name)}"></iframe>`;
      } else if (file.kind === "image") {
        preview.innerHTML = `<img src="${url}" alt="${escapeHtml(file.name)}">`;
      } else {
        preview.innerHTML = `<p>${escapeHtml(file.name)}</p>`;
      }
    } catch (e) {
      preview.innerHTML = `<p class="error">${escapeHtml(e.message)}</p>`;
    }
  }

  function openAttachmentModal(data) {
    closeAttachModal();
    attachModalState = data;
    const overlay = document.createElement("div");
    overlay.id = "attach-modal-overlay";
    overlay.className = "attach-modal-overlay";
    const listItems = (data.files || [])
      .map(
        (f, i) =>
          `<li><button type="button" class="attach-file-btn${i === 0 ? " active" : ""}" data-idx="${i}">${escapeHtml(f.name)}</button></li>`
      )
      .join("");
    overlay.innerHTML = `<div class="attach-modal" role="dialog" aria-modal="true">
      <div class="attach-modal-header">
        <h2>${escapeHtml(t("attachPreview"))} — ${escapeHtml(data.key_value)}</h2>
        <p class="text-muted">${escapeHtml(data.folder)}</p>
      </div>
      <div class="attach-modal-body">
        <ul class="attach-file-list">${listItems}</ul>
        <div id="attach-preview" class="attach-preview"></div>
      </div>
      <div class="arap-modal-actions">
        ${iconBtn(t("attachClose"), "exit", "btn secondary", 'data-act="attach-close"')}
      </div>
    </div>`;
    document.body.appendChild(overlay);
    if (data.files && data.files.length) showAttachmentPreview(data.files[0]);
    overlay.querySelectorAll(".attach-file-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        overlay.querySelectorAll(".attach-file-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        const idx = parseInt(btn.dataset.idx, 10);
        showAttachmentPreview(data.files[idx]);
      });
    });
    overlay.querySelector('[data-act="attach-close"]').addEventListener("click", closeAttachModal);
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeAttachModal();
    });
  }

  async function doAttachment(tab) {
    if (tab.selectedRow == null) {
      alert(t("attachSelectRow"));
      return;
    }
    const oldRow = tab.physicalRows[tab.selectedRow];
    try {
      const data = await api(`/work/${encodeURIComponent(tab.doProc)}/attachments`, {
        method: "POST",
        body: JSON.stringify({ old_row: oldRow }),
      });
      if (!data.files || !data.files.length) {
        alert(t("attachNoFiles", data.folder, data.key_value));
        return;
      }
      openAttachmentModal(data);
    } catch (e) {
      alert(e.message || t("attachSelectRow"));
    }
  }

  function closeArapModal() {
    const el = $("#arap-modal-overlay");
    if (el) el.remove();
    arapModalState = null;
  }

  function arapTitle(mode) {
    return mode === "AP" ? t("arapTitleAP") : t("arapTitleAR");
  }

  function arapPartyLabel(mode) {
    return mode === "AP" ? t("arapPartyAP") : t("arapPartyAR");
  }

  function arapHeaders() {
    return currentLang === "CHN"
      ? ["發票編號", "日期", "貨幣", "滙率", "發票金額", "已付金額", "發票餘額", "付款金額", "折扣金額"]
      : ["Invoice No.", "Date", "Curr.", "Rate", "Invoice Amt.", "Paid Amt.", "Balance", "Payment", "Discount"];
  }

  function arapViewState(state) {
    const doc = state.document || state;
    return {
      mode: doc.mode || state.mode,
      header: doc.header || state.header || {},
      lines: doc.lines || state.lines || [],
      totals: state.totals || {},
      selectedRow: state.selectedRow,
      keyword: state.keyword || "",
    };
  }

  function renderArapModalBody(state) {
    const view = arapViewState(state);
    const h = view.header;
    const partyText = `${h.party_key || ""}${h.party_name ? " - " + h.party_name : ""}`.trim();
    const headers = arapHeaders();
    const cols = ["inv_no", "date", "currency", "rate", "net_amt", "paid_amt", "balance", "pay_amount", "discount"];
    const rows = view.lines
      .map((ln, ri) => {
        const sel = view.selectedRow === ri ? " selected" : "";
        const cells = cols
          .map((c) => {
            const ro = ["inv_no", "date", "currency", "rate", "net_amt", "paid_amt", "balance"].includes(c);
            if (ro) return `<td>${escapeHtml(ln[c] || "")}</td>`;
            return `<td><input type="text" data-arap-row="${ri}" data-arap-col="${c}" value="${escapeHtml(ln[c] || "")}"></td>`;
          })
          .join("");
        return `<tr class="arap-row${sel}" data-arap-row="${ri}">${cells}</tr>`;
      })
      .join("");
    const totals = view.totals || {};
    return `
      <div class="arap-header-grid">
        <div class="arap-header-field"><label>${escapeHtml(t("arapVouKey"))}</label><input readonly value="${escapeHtml(h.vou_key || "")}"></div>
        <div class="arap-header-field"><label>${escapeHtml(t("arapSettleDate"))}</label><input readonly value="${escapeHtml(h.settle_date || "")}"></div>
        <div class="arap-header-field"><label>${escapeHtml(arapPartyLabel(view.mode))}</label><input readonly value="${escapeHtml(partyText)}"></div>
        <div class="arap-header-field"><label>${escapeHtml(t("arapSettleAmt"))}</label><input readonly value="${escapeHtml(h.settle_amount || "")}"></div>
      </div>
      <div class="arap-search-row">
        <label>${t("searchLabel")}</label>
        <input type="text" id="arap-search-input" value="${escapeHtml(view.keyword || "")}">
        ${iconBtn(t("search"), "search", "btn action-btn", 'data-arap-act="search"')}
        ${iconBtn(t("filter"), "filter", "btn action-btn", 'data-arap-act="filter"')}
      </div>
      <div class="arap-table-wrap">
        <table class="arap-table">
          <thead><tr>${headers.map((x) => `<th>${escapeHtml(x)}</th>`).join("")}</tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
      <div class="arap-totals">
        ${escapeHtml(t("recordNav", view.selectedRow != null ? view.selectedRow + 1 : null, view.lines.length))}
        | ${escapeHtml((totals.remaining || "0"))}
      </div>`;
  }

  function collectArapDocumentFromDom(overlay) {
    const doc = JSON.parse(JSON.stringify(arapModalState.document));
    overlay.querySelectorAll("[data-arap-col]").forEach((inp) => {
      const ri = parseInt(inp.dataset.arapRow, 10);
      const col = inp.dataset.arapCol;
      if (doc.lines[ri]) doc.lines[ri][col] = inp.value;
    });
    return doc;
  }

  function bindArapModalBodyEvents(tab) {
    const overlay = $("#arap-modal-overlay");
    if (!overlay || !arapModalState) return;
    const body = overlay.querySelector(".arap-modal-body");
    body.querySelectorAll(".arap-row").forEach((tr) => {
      tr.addEventListener("click", () => {
        arapModalState.selectedRow = parseInt(tr.dataset.arapRow, 10);
        body.innerHTML = renderArapModalBody(arapModalState);
        bindArapModalBodyEvents(tab);
      });
    });
    body.querySelectorAll('[data-arap-act="search"], [data-arap-act="filter"]').forEach((btn) => {
      btn.addEventListener("click", async () => {
        const act = btn.dataset.arapAct;
        const kw = ($("#arap-search-input", body) || {}).value || "";
        const doc = collectArapDocumentFromDom(overlay);
        try {
          const res = await api(`/work/${encodeURIComponent(tab.doProc)}/arap/filter`, {
            method: "POST",
            body: JSON.stringify({ document: doc, keyword: kw, as_filter: act === "filter" }),
          });
          arapModalState.document = {
            mode: res.mode,
            header: res.header,
            lines: res.lines,
          };
          arapModalState.totals = res.totals;
          arapModalState.keyword = kw;
          if (res.selected_index != null) arapModalState.selectedRow = res.selected_index;
          body.innerHTML = renderArapModalBody(arapModalState);
          bindArapModalBodyEvents(tab);
        } catch (e) {
          alert(e.message);
        }
      });
    });
  }

  function bindArapModalEvents(tab) {
    const overlay = $("#arap-modal-overlay");
    if (!overlay || !arapModalState) return;
    bindArapModalBodyEvents(tab);
    if (overlay.dataset.chromeBound) return;
    overlay.dataset.chromeBound = "1";
    overlay.querySelector('[data-arap-act="auto"]').addEventListener("click", async () => {
      const doc = collectArapDocumentFromDom(overlay);
      try {
        const res = await api(`/work/${encodeURIComponent(tab.doProc)}/arap/auto`, {
          method: "POST",
          body: JSON.stringify({ document: doc }),
        });
        arapModalState.document = { mode: res.mode, header: res.header, lines: res.lines };
        arapModalState.totals = res.totals;
        const body = overlay.querySelector(".arap-modal-body");
        body.innerHTML = renderArapModalBody(arapModalState);
        bindArapModalBodyEvents(tab);
      } catch (e) {
        alert(e.message);
      }
    });
    overlay.querySelector('[data-arap-act="save"]').addEventListener("click", async () => {
      const doc = collectArapDocumentFromDom(overlay);
      try {
        await api(`/work/${encodeURIComponent(tab.doProc)}/arap/save`, {
          method: "PUT",
          body: JSON.stringify({ document: doc }),
        });
        alert(t("arapSaved"));
        closeArapModal();
        await loadWorkData(tab, { asFilter: tab.filtered });
        renderTabs();
      } catch (e) {
        alert(e.message);
      }
    });
    overlay.querySelector('[data-arap-act="cancel"]').addEventListener("click", closeArapModal);
  }

  async function openArapModal(tab) {
    if (tab.selectedRow == null) {
      alert(t("arapSelectVoucher"));
      return;
    }
    const oldRow = tab.physicalRows[tab.selectedRow];
    try {
      const data = await api(`/work/${encodeURIComponent(tab.doProc)}/arap/load`, {
        method: "POST",
        body: JSON.stringify({ old_row: oldRow }),
      });
      closeArapModal();
      arapModalState = {
        tab,
        document: { mode: data.mode, header: data.header, lines: data.lines },
        totals: data.totals,
        mode: data.mode,
        selectedRow: 0,
        keyword: "",
      };
      const overlay = document.createElement("div");
      overlay.id = "arap-modal-overlay";
      overlay.className = "arap-modal-overlay";
      overlay.innerHTML = `<div class="arap-modal" role="dialog" aria-modal="true">
        <div class="arap-modal-header"><h2>${escapeHtml(arapTitle(data.mode))}</h2></div>
        <div class="arap-modal-body">${renderArapModalBody(arapModalState)}</div>
        <div class="arap-modal-actions">
          ${iconBtn(t("arapAuto"), "filter", "btn action-btn", 'data-arap-act="auto"')}
          ${iconBtn(t("save"), "save", "btn action-btn", 'data-arap-act="save"')}
          ${iconBtn(t("cancel"), "cancel", "btn secondary", 'data-arap-act="cancel"')}
        </div>
      </div>`;
      document.body.appendChild(overlay);
      bindArapModalEvents(tab);
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) closeArapModal();
      });
    } catch (e) {
      alert(e.message || t("otherNotConfigured"));
    }
  }

  async function doOther(tab) {
    await openArapModal(tab);
  }

  async function doFilter(tab, page) {
    tab.keyword = $(".search-input", page).value.trim();
    await loadWorkData(tab, { asFilter: true });
    tab.selectedRow = tab.rows.length ? 0 : null;
    renderTabs();
  }

  async function doDelete(tab) {
    if (tab.selectedRow == null) {
      alert(t("selectRow"));
      return;
    }
    if (!confirm(t("confirmDel"))) return;
    const oldRow = tab.physicalRows[tab.selectedRow];
    try {
      await api(`/work/${encodeURIComponent(tab.doProc)}/delete`, {
        method: "DELETE",
        body: JSON.stringify({ old_row: oldRow }),
      });
      tab.selectedRow = null;
      await loadWorkData(tab, { asFilter: tab.filtered });
      renderTabs();
    } catch (e) {
      alert(e.message || t("delFail"));
    }
  }

  function doPrint(tab) {
    if (!tab.rows.length) {
      alert(t("noPrint"));
      return;
    }
    openPrintModal(tab);
  }

  let printModalState = null;
  let printPreviewState = null;

  function ensurePrintPreviewOverlay() {
    let el = $("#print-preview-overlay");
    if (el) return el;
    el = document.createElement("div");
    el.id = "print-preview-overlay";
    el.className = "print-preview-overlay hidden";
    el.innerHTML = `<div class="print-preview-panel" role="dialog" aria-modal="true">
      <div class="print-preview-header">
        <h3 class="print-preview-title"></h3>
        <div class="print-preview-header-actions">
          <div class="print-preview-pdf-nav hidden">
            ${iconBtnOnly(t("navPrev"), "nav-prev", "btn secondary btn-icon-only", 'data-preview-act="prev"')}
            <span class="print-preview-pdf-index"></span>
            ${iconBtnOnly(t("navNext"), "nav-next", "btn secondary btn-icon-only", 'data-preview-act="next"')}
          </div>
          ${iconBtn(t("printPreviewOpenWindow"), "window-new", "btn secondary", 'data-preview-act="window"')}
          ${iconBtn(t("printPreviewClose"), "window-close", "btn secondary", 'data-preview-act="close"')}
        </div>
      </div>
      <iframe class="print-preview-frame" title="Print preview"></iframe>
    </div>`;
    document.body.appendChild(el);
    el.addEventListener("click", (e) => {
      if (e.target === el) closePrintPreview();
    });
    $(".print-preview-title", el).textContent = t("printPreviewTitle");
    el.querySelector('[data-preview-act="window"]').addEventListener("click", () => {
      openPrintPreviewInNewWindow();
    });
    el.querySelector('[data-preview-act="close"]').addEventListener("click", closePrintPreview);
    el.querySelector('[data-preview-act="prev"]').addEventListener("click", () => {
      shiftPrintPreviewPdf(-1);
    });
    el.querySelector('[data-preview-act="next"]').addEventListener("click", () => {
      shiftPrintPreviewPdf(1);
    });
    return el;
  }

  function revokePrintPreviewBlobUrls() {
    if (!printPreviewState || !printPreviewState.blobUrls) return;
    printPreviewState.blobUrls.forEach((url) => {
      try {
        URL.revokeObjectURL(url);
      } catch (_) {
        /* ignore */
      }
    });
  }

  function renderPrintPreviewPdfAt(index) {
    if (!printPreviewState || printPreviewState.kind !== "pdf-list") return;
    const overlay = $("#print-preview-overlay");
    const frame = overlay.querySelector(".print-preview-frame");
    const nav = overlay.querySelector(".print-preview-pdf-nav");
    const idxEl = overlay.querySelector(".print-preview-pdf-index");
    const total = printPreviewState.pdfs.length;
    const i = Math.max(0, Math.min(index, total - 1));
    printPreviewState.index = i;
    frame.removeAttribute("srcdoc");
    frame.src = printPreviewState.blobUrls[i];
    if (total > 1) {
      nav.classList.remove("hidden");
      idxEl.textContent = t("printPreviewPdfNav", i + 1, total);
    } else {
      nav.classList.add("hidden");
    }
  }

  function shiftPrintPreviewPdf(delta) {
    if (!printPreviewState || printPreviewState.kind !== "pdf-list") return;
    renderPrintPreviewPdfAt((printPreviewState.index || 0) + delta);
  }

  function showPrintPreviewPdfList(b64List) {
    revokePrintPreviewBlobUrls();
    const blobUrls = b64List.map((b64) => {
      const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: "application/pdf" });
      return URL.createObjectURL(blob);
    });
    printPreviewState = {
      kind: "pdf-list",
      pdfs: b64List,
      blobUrls,
      index: 0,
      content: blobUrls[0],
    };
    const overlay = ensurePrintPreviewOverlay();
    overlay.classList.remove("hidden");
    renderPrintPreviewPdfAt(0);
  }

  function closePrintPreview() {
    const el = $("#print-preview-overlay");
    if (!el) return;
    const frame = el.querySelector(".print-preview-frame");
    if (frame) {
      frame.removeAttribute("src");
      frame.removeAttribute("srcdoc");
    }
    revokePrintPreviewBlobUrls();
    printPreviewState = null;
    el.classList.add("hidden");
  }

  function showPrintPreview(content, kind) {
    revokePrintPreviewBlobUrls();
    const overlay = ensurePrintPreviewOverlay();
    const frame = overlay.querySelector(".print-preview-frame");
    const nav = overlay.querySelector(".print-preview-pdf-nav");
    if (nav) nav.classList.add("hidden");
    printPreviewState = { content, kind, blobUrls: [] };
    if (kind === "pdf") {
      frame.removeAttribute("srcdoc");
      frame.src = content;
      printPreviewState.blobUrls = [content];
    } else {
      frame.removeAttribute("src");
      frame.srcdoc = content;
    }
    overlay.classList.remove("hidden");
  }

  function openPrintPreviewInNewWindow() {
    if (!printPreviewState) return;
    const { content, kind, blobUrls, index } = printPreviewState;
    if (kind === "pdf-list" && blobUrls && blobUrls.length) {
      window.open(blobUrls[index || 0], "_blank", "noopener,noreferrer");
      return;
    }
    if (kind === "pdf") {
      window.open(content, "_blank", "noopener,noreferrer");
      return;
    }
    const w = window.open("", "_blank", "noopener,noreferrer");
    if (!w) {
      alert(t("printPreviewBlocked"));
      return;
    }
    w.document.write(content);
    w.document.close();
  }

  function syncPrintDateFromYm(state, dateText) {
    const parsed = parseAppDate(normalizeAppDateText(dateText || ""));
    state.printDateFromYm = parsed ? [parsed.y, parsed.mo] : null;
  }

  function isPrintReportListOrDocument(state) {
    return !!(state && (state.isList || state.isDocument));
  }

  function onPrintDateFromInput(body, state) {
    if (isPrintReportListOrDocument(state)) return;
    const fromEl = $("#print-date-from", body);
    if (!fromEl) return;
    fromEl.value = normalizeAppDateText(fromEl.value);
    const parsed = parseAppDate(fromEl.value);
    if (!parsed) {
      state.printDateFromYm = null;
      return;
    }
    const ymKey = `${parsed.y}-${parsed.mo}`;
    const lastKey = state.printDateFromYm
      ? `${state.printDateFromYm[0]}-${state.printDateFromYm[1]}`
      : null;
    if (ymKey === lastKey) return;
    state.printDateFromYm = [parsed.y, parsed.mo];
    const lastDay = lastDayOfMonth(parsed.y, parsed.mo);
    const toEl = $("#print-date-to", body);
    if (toEl) {
      toEl.value = `${parsed.y}/${String(parsed.mo).padStart(2, "0")}/${String(lastDay).padStart(2, "0")}`;
    }
  }

  function openPrintDatePicker(targetKey) {
    const overlay = $("#print-modal-overlay");
    if (!overlay) return;
    const inputId = targetKey === "date-to" ? "#print-date-to" : "#print-date-from";
    const targetEl = overlay.querySelector(inputId);
    if (!targetEl) return;
    openAppDatePicker(targetEl, () => {
      if (targetKey === "date-from") {
        onPrintDateFromInput(overlay.querySelector(".print-modal-body"), printModalState);
      }
    });
  }

  function getPrintParamsFromModal(root) {
    const reportEl = root.querySelector("#print-report");
    const printerEl = root.querySelector("#print-printer");
    return {
      report_index: reportEl ? parseInt(reportEl.value, 10) || 0 : 0,
      printer_index: printerEl ? parseInt(printerEl.value, 10) || 0 : 0,
      inv_from: (root.querySelector("#print-inv-from") || {}).value || "",
      inv_to: (root.querySelector("#print-inv-to") || {}).value || "",
      date_from: normalizeAppDateText((root.querySelector("#print-date-from") || {}).value || ""),
      date_to: normalizeAppDateText((root.querySelector("#print-date-to") || {}).value || ""),
    };
  }

  function closePrintModal() {
    closePrintPreview();
    const el = $("#print-modal-overlay");
    if (el) el.remove();
    printModalState = null;
  }

  function ensurePrintModalOverlay() {
    let el = $("#print-modal-overlay");
    if (el) return el;
    el = document.createElement("div");
    el.id = "print-modal-overlay";
    el.className = "print-modal-overlay hidden";
    el.innerHTML = `<div class="print-modal" role="dialog" aria-modal="true">
      <div class="print-modal-header"><h2 class="print-modal-title"></h2></div>
      <div class="print-modal-body"></div>
      <div class="print-modal-actions"></div>
    </div>`;
    document.body.appendChild(el);
    el.addEventListener("click", (e) => {
      if (e.target !== el) return;
      const pick = $("#print-pick-overlay");
      if (pick && !pick.classList.contains("hidden")) return;
      closePrintModal();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      const pick = $("#print-pick-overlay");
      if (pick && !pick.classList.contains("hidden")) {
        pick.classList.add("hidden");
        return;
      }
      const preview = $("#print-preview-overlay");
      if (preview && !preview.classList.contains("hidden")) {
        closePrintPreview();
        return;
      }
      const modal = $("#print-modal-overlay");
      if (modal && !modal.classList.contains("hidden")) closePrintModal();
    });
    return el;
  }

  async function openPrintModal(tab) {
    try {
      const init = await api(`/work/${encodeURIComponent(tab.doProc)}/print/init`, {
        method: "POST",
        body: JSON.stringify({ selected_row: tab.selectedRow }),
      });
      printModalState = {
        tab,
        init,
        isList: !!init.is_list,
        isDocument: !!init.is_document,
        printDateFromYm: null,
      };
      syncPrintDateFromYm(printModalState, init.date_from);
      renderPrintModal(init);
      if (init.no_report) {
        alert(init.message || t("printNoReport"));
        await doPrintPreview();
        closePrintModal();
        return;
      }
    } catch (e) {
      alert(e.message || t("printPreviewFail"));
    }
  }

  function renderPrintModal(init) {
    const overlay = ensurePrintModalOverlay();
    overlay.classList.remove("hidden");
    const modal = overlay.querySelector(".print-modal");
    $(".print-modal-title", modal).textContent = t("printTitle");
    const body = $(".print-modal-body", modal);
    const docLabel = init.doc_no_label || (currentLang === "CHN" ? "記錄" : "record");
    const reportOpts = (init.reports || [])
      .map((r) => `<option value="${r.index}">${escapeHtml(r.title || "Report")}</option>`)
      .join("");
    const printerOpts = (init.printers || [])
      .map((p) => `<option value="${p.index}">${escapeHtml(p.name || "Printer")}</option>`)
      .join("");
    const reportEmptyNote =
      !(init.reports || []).length && !init.no_report
        ? `<p class="print-report-empty">${escapeHtml(t("printPreviewFail"))}</p>`
        : "";
    body.innerHTML = `
      <div class="print-form-grid">
        <label>${escapeHtml(t("printPrinter"))}</label>
        <select id="print-printer">${printerOpts}</select>
        <label>${escapeHtml(t("printReport"))}</label>
        <select id="print-report">${reportOpts || `<option value="0">${escapeHtml(currentLang === "CHN" ? "資料清單" : "Data list")}</option>`}</select>
        ${reportEmptyNote}
        <label>${escapeHtml(t("printFromNo", docLabel))}</label>
        <div class="print-field-row">
          <input type="text" id="print-inv-from" value="${escapeHtml(init.inv_from || "")}">
          ${iconBtnOnly(t("printPickBtn"), "document-open", "btn secondary print-pick-btn btn-icon-only", 'data-pick="inv-from"')}
        </div>
        <label>${escapeHtml(t("printToNo", docLabel))}</label>
        <div class="print-field-row">
          <input type="text" id="print-inv-to" value="${escapeHtml(init.inv_to || "")}">
          ${iconBtnOnly(t("printPickBtn"), "document-open", "btn secondary print-pick-btn btn-icon-only", 'data-pick="inv-to"')}
        </div>
        <label>${escapeHtml(t("printFromDate"))}</label>
        <div class="print-field-row">
          <input type="text" class="app-date-input" id="print-date-from" placeholder="yyyy/MM/dd" value="${escapeHtml(normalizeAppDateText(init.date_from || ""))}">
          ${iconBtnOnly(t("printDatePickBtn"), "view-calendar", "btn secondary print-pick-btn btn-icon-only", 'data-pick="date-from"')}
          ${iconBtnOnly(t("printClearDate"), "edit-clear", "btn secondary print-clear-btn btn-icon-only", 'data-clear="date-from"')}
        </div>
        <label>${escapeHtml(t("printToDate"))}</label>
        <div class="print-field-row">
          <input type="text" class="app-date-input" id="print-date-to" placeholder="yyyy/MM/dd" value="${escapeHtml(normalizeAppDateText(init.date_to || ""))}">
          ${iconBtnOnly(t("printDatePickBtn"), "view-calendar", "btn secondary print-pick-btn btn-icon-only", 'data-pick="date-to"')}
          ${iconBtnOnly(t("printClearDate"), "edit-clear", "btn secondary print-clear-btn btn-icon-only", 'data-clear="date-to"')}
        </div>
      </div>`;
    $("#print-printer", body).value = String(init.printer_index ?? 0);
    $("#print-report", body).value = String(init.report_index ?? 0);

    const actions = $(".print-modal-actions", modal);
    actions.innerHTML = `
      ${iconBtn(t("printPreview"), "print", "btn action-btn", 'data-print-act="preview"')}
      ${iconBtn(t("printBtn"), "document-print", "btn action-btn", 'data-print-act="print"')}
      ${iconBtn(t("printExportPdf"), "application-pdf", "btn action-btn", 'data-print-act="pdf"')}
      ${iconBtn(t("printExportXlsx"), "x-office-spreadsheet", "btn action-btn", 'data-print-act="xlsx"')}
      ${iconBtn(t("printExportDocx"), "x-office-document", "btn action-btn", 'data-print-act="docx"')}
      ${iconBtn(t("printEmail"), "mail-message", "btn action-btn", 'data-print-act="email"')}
      ${iconBtn(t("printExit"), "exit", "btn action-btn", 'data-print-act="exit"')}`;

    $("#print-report", body).addEventListener("change", async () => {
      try {
        const reportIndex = parseInt($("#print-report", body).value, 10) || 0;
        const defs = await api(
          `/work/${encodeURIComponent(printModalState.tab.doProc)}/print/defaults`,
          { method: "POST", body: JSON.stringify({ report_index: reportIndex }) }
        );
        $("#print-inv-from", body).value = defs.inv_from || "";
        $("#print-inv-to", body).value = defs.inv_to || "";
        $("#print-date-from", body).value = normalizeAppDateText(defs.date_from || "");
        $("#print-date-to", body).value = normalizeAppDateText(defs.date_to || "");
        if (printModalState) {
          printModalState.isList = !!defs.is_list;
          printModalState.isDocument = !!defs.is_document;
          syncPrintDateFromYm(printModalState, defs.date_from || "");
        }
      } catch (e) {
        alert(e.message || t("printPreviewFail"));
      }
    });

    $("#print-date-from", body).addEventListener("input", () => {
      onPrintDateFromInput(body, printModalState);
    });

    $$(".print-pick-btn", body).forEach((btn) => {
      const pick = btn.dataset.pick;
      btn.addEventListener("click", () => {
        if (pick === "date-from" || pick === "date-to") {
          openPrintDatePicker(pick);
          return;
        }
        openPrintPickModal(pick);
      });
    });
    $$(".print-clear-btn", body).forEach((btn) => {
      btn.addEventListener("click", () => {
        const key = btn.dataset.clear;
        const el = body.querySelector(`#print-${key}`);
        if (el) el.value = "";
        if (key === "date-from") {
          const toEl = body.querySelector("#print-date-to");
          if (toEl) toEl.value = "";
          if (printModalState) printModalState.printDateFromYm = null;
        }
      });
    });

    $$("[data-print-act]", actions).forEach((btn) => {
      btn.addEventListener("click", () => handlePrintAction(btn.dataset.printAct));
    });
  }

  async function handlePrintAction(act) {
    if (!printModalState) return;
    if (act === "exit") {
      closePrintModal();
      return;
    }
    if (act === "preview") {
      await doPrintPreview();
      return;
    }
    if (act === "print") {
      await doPrintExecute();
      return;
    }
    if (act === "pdf" || act === "xlsx" || act === "docx") {
      await doPrintExport(act);
      return;
    }
    if (act === "email") {
      await doPrintEmail();
    }
  }

  async function doPrintPreview() {
    if (!printModalState) return;
    const overlay = $("#print-modal-overlay");
    const params = getPrintParamsFromModal(overlay);
    try {
      const res = await api(
        `/work/${encodeURIComponent(printModalState.tab.doProc)}/print/preview`,
        { method: "POST", body: JSON.stringify(params) }
      );
      if (!res.ok) {
        alert(res.message || t("printPreviewFail"));
        return;
      }
      if (res.kind === "pdf" && res.pdfs_base64 && res.pdfs_base64.length) {
        showPrintPreviewPdfList(res.pdfs_base64);
        return;
      }
      if (res.html) {
        showPrintPreview(res.html, "html");
        return;
      }
      alert(res.message || t("printPreviewFail"));
    } catch (e) {
      alert(e.message || t("printPreviewFail"));
    }
  }

  async function doPrintExecute() {
    if (!printModalState) return;
    const overlay = $("#print-modal-overlay");
    const params = getPrintParamsFromModal(overlay);
    try {
      const res = await api(
        `/work/${encodeURIComponent(printModalState.tab.doProc)}/print/print`,
        { method: "POST", body: JSON.stringify(params) }
      );
      alert(t("printSuccess", res.message));
    } catch (e) {
      alert(e.message || t("printFail"));
    }
  }

  async function doPrintExport(kind) {
    if (!printModalState) return;
    const overlay = $("#print-modal-overlay");
    const params = getPrintParamsFromModal(overlay);
    const path = `/work/${encodeURIComponent(printModalState.tab.doProc)}/print/export/${kind}`;
    try {
      const headers = { "Content-Type": "application/json" };
      if (token) headers.Authorization = `Bearer ${token}`;
      const res = await fetch(`/api${path}`, {
        method: "POST",
        headers,
        body: JSON.stringify(params),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(apiErrorMessage(data, t("printExportFail")));
      }
      const blob = await res.blob();
      const ext = kind === "pdf" ? "pdf" : kind === "xlsx" ? "xlsx" : "docx";
      const filename = `report.${ext}`;
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      alert(t("printExportOk", filename));
    } catch (e) {
      alert(e.message || t("printExportFail"));
    }
  }

  async function doPrintEmail() {
    if (!printModalState) return;
    const overlay = $("#print-modal-overlay");
    const params = getPrintParamsFromModal(overlay);
    try {
      const res = await api(
        `/work/${encodeURIComponent(printModalState.tab.doProc)}/print/email-text`,
        { method: "POST", body: JSON.stringify(params) }
      );
      if (!res.plain_text) {
        alert(t("printPreviewFail"));
        return;
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(res.plain_text);
      }
      alert(res.hint || t("printEmailCopied"));
      const sub = encodeURIComponent(res.subject || "Report");
      const body = encodeURIComponent((res.hint || "").slice(0, 600));
      window.location.href = `mailto:?subject=${sub}&body=${body}`;
    } catch (e) {
      alert(e.message || t("printPreviewFail"));
    }
  }

  async function openPrintPickModal(targetKey) {
    if (!printModalState) return;
    const overlay = $("#print-modal-overlay");
    const params = getPrintParamsFromModal(overlay);
    let pickData;
    try {
      pickData = await api(
        `/work/${encodeURIComponent(printModalState.tab.doProc)}/print/pick-rows`,
        { method: "POST", body: JSON.stringify({ report_index: params.report_index }) }
      );
    } catch (e) {
      alert(e.message || t("printPickNoData"));
      return;
    }
    if (!pickData.rows || !pickData.rows.length) {
      alert(t("printPickNoData"));
      return;
    }
    const fields = pickData.fields || [];
    const columns = pickData.columns || fields.map((f) => ({ name: f, title: f }));
    let pickOverlay = $("#print-pick-overlay");
    if (!pickOverlay) {
      pickOverlay = document.createElement("div");
      pickOverlay.id = "print-pick-overlay";
      pickOverlay.className = "print-pick-overlay hidden";
      document.body.appendChild(pickOverlay);
      pickOverlay.addEventListener("click", (e) => {
        if (e.target === pickOverlay) pickOverlay.classList.add("hidden");
      });
    }
    document.body.appendChild(pickOverlay);
    pickOverlay.classList.remove("hidden");
    const currentVal = (
      (targetKey === "inv-to"
        ? overlay.querySelector("#print-inv-to")
        : overlay.querySelector("#print-inv-from")) || {}
    ).value || "";
    pickOverlay.innerHTML = `
      <div class="print-pick-modal" role="dialog" aria-modal="true">
        <h3>${escapeHtml(t("printPickRecord"))}</h3>
        <input type="text" class="print-pick-filter" placeholder="${escapeHtml(t("printPickFilter"))}">
        <div class="print-pick-table-wrap">
          <table class="print-pick-table"><thead><tr>
            ${columns.map((c) => `<th>${escapeHtml(c.title || c.name)}</th>`).join("")}
          </tr></thead><tbody></tbody></table>
        </div>
        <div class="print-pick-actions">
          ${iconBtn(t("printPickOk"), "dialog-ok", "btn action-btn", "data-pick-ok")}
          ${iconBtn(t("printPickCancel"), "cancel", "btn action-btn", "data-pick-cancel")}
        </div>
      </div>`;
    const pickModal = pickOverlay.querySelector(".print-pick-modal");
    if (pickModal) {
      pickModal.addEventListener("click", (e) => e.stopPropagation());
    }
    const tbody = pickOverlay.querySelector("tbody");
    const filterEl = pickOverlay.querySelector(".print-pick-filter");
    let filteredSnapshot = [];
    let selectedFilteredIdx = 0;
    const currentNorm = String(currentVal).trim().toLowerCase();

    function renderPickRows(kw) {
      const keyword = (kw || "").trim().toLowerCase();
      filteredSnapshot = [];
      tbody.innerHTML = "";
      let matchedCurrent = false;
      pickData.rows.forEach((row, i) => {
        const line = row.join("\t").toLowerCase();
        if (keyword && !line.includes(keyword)) return;
        const snapIdx = filteredSnapshot.length;
        filteredSnapshot.push(i);
        const tr = document.createElement("tr");
        tr.dataset.filtered = String(snapIdx);
        const keyVal = (pickData.key_values[i] || "").trim();
        if (!matchedCurrent && currentNorm && keyVal.toLowerCase() === currentNorm) {
          selectedFilteredIdx = snapIdx;
          matchedCurrent = true;
        }
        if (snapIdx === selectedFilteredIdx) tr.classList.add("selected");
        tr.innerHTML = row.map((c) => `<td>${escapeHtml(c)}</td>`).join("");
        tr.addEventListener("click", () => {
          selectedFilteredIdx = parseInt(tr.dataset.filtered, 10);
          $$("tr", tbody).forEach((r) =>
            r.classList.toggle("selected", parseInt(r.dataset.filtered, 10) === selectedFilteredIdx)
          );
        });
        tr.addEventListener("dblclick", () => confirmPick());
        tbody.appendChild(tr);
      });
      if (!filteredSnapshot.length) {
        selectedFilteredIdx = 0;
        return;
      }
      if (selectedFilteredIdx >= filteredSnapshot.length) selectedFilteredIdx = 0;
      $$("tr", tbody).forEach((r) =>
        r.classList.toggle("selected", parseInt(r.dataset.filtered, 10) === selectedFilteredIdx)
      );
    }

    function confirmPick() {
      if (!filteredSnapshot.length) return;
      const rowIdx = filteredSnapshot[selectedFilteredIdx];
      if (rowIdx == null || rowIdx < 0) return;
      const val = (pickData.key_values[rowIdx] || "").trim();
      if (!val) {
        alert(t("printPickNoKey"));
        return;
      }
      const mainOverlay = $("#print-modal-overlay");
      const inputId = targetKey === "inv-to" ? "#print-inv-to" : "#print-inv-from";
      const input = mainOverlay && mainOverlay.querySelector(inputId);
      if (input) input.value = val;
      pickOverlay.classList.add("hidden");
    }

    filterEl.addEventListener("input", () => {
      selectedFilteredIdx = 0;
      renderPickRows(filterEl.value);
    });
    filterEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        confirmPick();
      }
    });
    pickOverlay.querySelector("[data-pick-ok]").addEventListener("click", confirmPick);
    pickOverlay.querySelector("[data-pick-cancel]").addEventListener("click", () => {
      pickOverlay.classList.add("hidden");
    });
    renderPickRows("");
    requestAnimationFrame(() => filterEl.focus());
  }

  function getFormFieldElement(page, detail, fieldName) {
    const meta = detail.formColumns.find((c) => c.name === fieldName) || { name: fieldName };
    if (isBoolField(meta)) {
      return page.querySelector(`select[data-field="${CSS.escape(fieldName)}"]`);
    }
    if (isLongTextField(meta)) {
      return page.querySelector(`textarea[data-field="${CSS.escape(fieldName)}"]`);
    }
    return page.querySelector(`input[type="text"][data-field="${CSS.escape(fieldName)}"]`);
  }

  function getFormFocusOrder(page, detail) {
    const order = [];
    for (const name of detail.formFields) {
      const el = getFormFieldElement(page, detail, name);
      if (el) order.push(el);
    }
    return order;
  }

  function isFormFieldControl(el) {
    if (!el || !el.dataset || !el.dataset.field) return false;
    if (!el.closest(".detail-form-area")) return false;
    const tag = el.tagName;
    return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
  }

  function isFormNavNextKey(e) {
    return e.key === "Enter" || e.key === "ArrowDown" || e.code === "ArrowDown";
  }

  function isFormNavPrevKey(e) {
    return e.key === "ArrowUp" || e.code === "ArrowUp";
  }

  function focusFormFieldElement(page, el) {
    if (!el) return;
    activateFormTabForElement(page, el);
    requestAnimationFrame(() => {
      el.focus({ preventScroll: false });
      if (typeof el.select === "function" && el.tagName !== "SELECT") el.select();
    });
  }

  function focusFormFieldByDirection(page, detail, currentEl, direction) {
    const order = getFormFocusOrder(page, detail);
    const idx = order.indexOf(currentEl);
    if (idx < 0) return false;

    if (direction > 0) {
      if (idx + 1 < order.length) {
        focusFormFieldElement(page, order[idx + 1]);
        return true;
      }
      if (detail.txFiles.length) {
        const tx = detail.txFiles[0];
        const search = page.querySelector(`.tx-search-input[data-tx="${CSS.escape(tx)}"]`);
        if (search) {
          activateTxTabForElement(page, search);
          search.focus();
          return true;
        }
        const cell = page.querySelector(`.tx-table[data-tx="${CSS.escape(tx)}"] .tx-cell`);
        if (cell) {
          activateTxTabForElement(page, cell);
          cell.focus();
          return true;
        }
      }
      const saveBtn = page.querySelector('[data-act="save"]');
      if (saveBtn) {
        saveBtn.focus();
        return true;
      }
      return false;
    }

    if (idx > 0) {
      focusFormFieldElement(page, order[idx - 1]);
      return true;
    }
    return false;
  }

  function focusNextFormField(page, detail, currentEl) {
    return focusFormFieldByDirection(page, detail, currentEl, 1);
  }

  function focusPrevFormField(page, detail, currentEl) {
    return focusFormFieldByDirection(page, detail, currentEl, -1);
  }

  function bindDetailFormFieldNavigation(page, detail) {
    const area = $(".detail-form-area", page);
    if (!area) return;
    area.addEventListener(
      "keydown",
      (e) => {
        if (e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) return;
        const el = e.target;
        if (!isFormFieldControl(el)) return;
        const isTextarea = el.tagName === "TEXTAREA";
        if (isFormNavNextKey(e) && isTextarea && e.key === "Enter") return;
        if (!isFormNavNextKey(e) && !isFormNavPrevKey(e)) return;
        e.preventDefault();
        e.stopPropagation();
        if (isFormNavPrevKey(e)) focusPrevFormField(page, detail, el);
        else focusNextFormField(page, detail, el);
      },
      true
    );
  }

  function refreshFormModalUI(detail) {
    const overlay = $("#form-modal-overlay");
    if (!overlay) return;
    const body = overlay.querySelector(".form-modal-body");
    if (!body) return;
    body.innerHTML = renderDetailPage(detail);
    const page = body.querySelector(".detail-page");
    bindDetailPageEvents(detail, {
      onCancel: closeFormModal,
      onSaved: closeFormModal,
      rootPage: page,
    });
    bindDateFields(page);
  }

  function bindDetailPageEvents(detail, opts = {}) {
    const page = opts.rootPage || $(`.detail-page[data-tab="${detail.id}"]`);
    if (!page) return;
    const refreshUi = () => {
      if (detail.inModal) refreshFormModalUI(detail);
      else renderTabs();
    };

    bindDetailFormFieldNavigation(page, detail);
    bindFormTabEvents(page);
    bindTxTabEvents(page, detail);

    detail.txFiles.forEach((tx) => bindTxGridColumnResize(page, detail, tx));

    $('[data-act="cancel"]', page).addEventListener("click", () => {
      if (opts.onCancel) opts.onCancel();
      else closeTab(detail.id);
    });

    $$(".tx-act", page).forEach((btn) => {
      btn.addEventListener("click", () => {
        const tx = btn.dataset.tx;
        const act = btn.dataset.txAct;
        const txd = detail.txData[tx];
        if (!txd) return;
        collectTxPhysicalRowsFromPage(page, detail);

        if (act === "add") {
          const formValues = collectFormValues(page);
          const mk = resolveMasterKeyForTx(detail, formValues);
          const keyCol = txKeyColOnTable(txd, mk.col);
          txd.physical_rows.push(createEmptyTxRow(txd, keyCol, mk.val));
          txd.selectedRow = txd.physical_rows.length - 1;
          syncTxDisplayRows(txd);
          refreshUi();
        } else if (act === "edit") {
          if (txd.selectedRow == null) {
            alert(t("selectRow"));
            return;
          }
          const inp = page.querySelector(
            `.tx-table[data-tx="${CSS.escape(tx)}"] tr[data-tx-row="${txd.selectedRow}"] .tx-cell`
          );
          if (inp) inp.focus();
        } else if (act === "delete") {
          if (txd.selectedRow == null) {
            alert(t("selectRow"));
            return;
          }
          if (!confirm(t("confirmTxDel"))) return;
          txd.physical_rows.splice(txd.selectedRow, 1);
          txd.selectedRow = txd.physical_rows.length
            ? Math.min(txd.selectedRow, txd.physical_rows.length - 1)
            : null;
          syncTxDisplayRows(txd);
          refreshUi();
        } else if (act === "copy") {
          if (txd.selectedRow == null) {
            alert(t("selectRow"));
            return;
          }
          const copy = [...txd.physical_rows[txd.selectedRow]];
          txd.physical_rows.splice(txd.selectedRow + 1, 0, copy);
          txd.selectedRow = txd.selectedRow + 1;
          syncTxDisplayRows(txd);
          refreshUi();
        } else if (act === "search") {
          const inp = page.querySelector(`.tx-search-input[data-tx="${CSS.escape(tx)}"]`);
          const kw = ((inp && inp.value) || "").trim().toLowerCase();
          txd.keyword = kw;
          if (!kw) return;
          const idx = txd.physical_rows.findIndex((row) =>
            row.some((c) => String(c).toLowerCase().includes(kw))
          );
          if (idx >= 0) {
            selectTxRow(page, detail, tx, idx);
          }
        }
      });
    });

    $$(".tx-nav", page).forEach((btn) => {
      btn.addEventListener("click", () => {
        if (btn.disabled) return;
        navigateTxGrid(page, detail, btn.dataset.tx, btn.dataset.nav);
      });
    });

    $$(".tx-table tbody tr[data-tx-row]", page).forEach((tr) => {
      tr.addEventListener("click", (e) => {
        if (e.target.closest(".tx-cell")) return;
        const tx = tr.dataset.tx;
        selectTxRow(page, detail, tx, parseInt(tr.dataset.txRow, 10));
      });
    });

    detail.txFiles.forEach((tx) => {
      const txd = detail.txData[tx];
      if (txd) updateTxSelectionUi(page, tx, txd);
    });

    bindTxCellInputs(page, detail);

    $$(".tx-search-input", page).forEach((inp) => {
      inp.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          const tx = inp.dataset.tx;
          const btn = page.querySelector(`.tx-act[data-tx="${CSS.escape(tx)}"][data-tx-act="search"]`);
          if (btn) btn.click();
        }
      });
    });

    $('[data-act="save"]', page).addEventListener("click", async () => {
      const errEl = $(".detail-error", page);
      errEl.classList.add("hidden");
      try {
        await persistDetailRecord(detail, page);
        if (opts.onSaved) opts.onSaved();
        else closeTab(detail.id);
      } catch (e) {
        errEl.textContent = e.message;
        errEl.classList.remove("hidden");
      }
    });
    bindDateFields(page);
  }

  function submitLogin() {
    login($("#login-user").value, $("#login-password").value, $("#login-company").value);
  }

  function bindLoginNavigation() {
    const userEl = $("#login-user");
    const pwEl = $("#login-password");
    const coEl = $("#login-company");
    const dtEl = $("#login-date");

    userEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        pwEl.focus();
      }
    });
    pwEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        tryLastCompany(userEl.value, pwEl.value).finally(() => coEl.focus());
      }
    });
    coEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        dtEl.focus();
      }
    });
    dtEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        submitLogin();
      }
    });
    dtEl.addEventListener("blur", () => {
      dtEl.value = normalizeAppDateText(dtEl.value);
    });
    pwEl.addEventListener("blur", () => {
      tryLastCompany(userEl.value, pwEl.value);
    });
  }

  $("#login-form").addEventListener("submit", (e) => {
    e.preventDefault();
    submitLogin();
  });
  $("#btn-login-ok").addEventListener("click", submitLogin);
  $("#btn-login-cancel").addEventListener("click", () => {
    hideLoginError();
    $("#login-user").value = "";
    $("#login-password").value = "";
    initLoginDate();
    $("#login-user").focus();
  });
  $("#btn-logout").addEventListener("click", logout);
  $("#lang-select").addEventListener("change", async (e) => {
    currentLang = e.target.value;
    refreshTopbarI18n();
    try {
      await api("/settings/language", {
        method: "POST",
        body: JSON.stringify({ lang: currentLang }),
      });
      await refreshMenu();
      for (const tab of openTabs.filter((x) => x.type === "work")) {
        await loadWorkData(tab, { asFilter: tab.filtered });
      }
      renderTabs();
    } catch (err) {
      alert(err.message);
    }
  });
  $("#btn-switch-desktop").addEventListener("click", () => {
    alert("請使用 python launcher.py --mode desktop 或 --mode both 啟動桌面介面。");
  });
  const menuModeSel = $("#menu-mode-select");
  if (menuModeSel) {
    menuModeSel.value = loadMenuMode();
    menuModeSel.addEventListener("change", (e) => {
      saveMenuMode(e.target.value);
      renderMenu();
    });
  }

  async function init() {
    applyFontPtToDocument();
    initLoginDate();
    decorateChromeButtons();
    bindLoginNavigation();
    try {
      await loadCompanies();
    } catch (_) {}
    if (token && (await restoreSession())) {
      showMain();
      try {
        await refreshMenu();
        updateUserInfo();
      } catch (_) {
        logout();
      }
    } else {
      showLogin();
      $("#login-user").focus();
    }
  }

  init();
})();
