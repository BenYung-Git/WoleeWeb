from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from core.auth import (
    UserSession,
    authenticate,
    detect_last_company_by_credentials,
    load_company_keys,
    record_login_success,
    resolve_sys_data_path,
    resolve_user_data_path,
)
from core.data_dictionary import (
    ColumnTitle,
    DataDictionary,
    LanguageCode,
    WorkActionFlags,
    resolve_work_actions_for_program,
)
from core.db_backend import DbBackendBase
from core.db_factory import (
    get_backend_for_path,
    resolve_company_db_path,
    resolve_metadata_db_path,
    resolve_program_company_key,
    ensure_company_db_path,
    validate_company_db,
)
from core.display_format import format_cell_display, grid_column_align, normalize_storage_value
from core.arap_settlement_service import (
    SettlementDocument,
    SettlementHeader,
    SettlementLine,
    auto_settle_lines,
    filter_lines,
    find_line_index,
    is_arap_settlement_program,
    load_settlement,
    remaining_settlement,
    save_settlement,
    sum_totals,
)
from core.attachment_service import (
    is_image_path,
    is_pdf_path,
    resolve_attachments_for_row,
)
from core.menu_loader import MainMenuGroup, ProgramItem, ProgramRepository


@dataclass
class WorkSchema:
    """開啟作業時回傳的結構定義。"""

    do_proc: str
    table_name: str
    rule_proc: str
    db_path: str
    grid_fields: List[str]
    form_fields: List[str]
    physical_fields: List[str]
    tx_files: List[str]
    menu_title: str
    columns: List[Dict[str, Any]]
    form_columns: List[Dict[str, Any]] = field(default_factory=list)
    print_doc_key_column: Optional[str] = None
    work_actions: WorkActionFlags = field(default_factory=WorkActionFlags)


@dataclass
class AppRuntime:
    """單一登入 session 的執行環境。"""

    base_dir: str
    session: UserSession
    lang: LanguageCode = "CHN"
    mdb_path: str = ""
    user_data_path: str = ""
    data_dict: DataDictionary = field(init=False)
    program_repo: ProgramRepository = field(init=False)
    _program_loaded: bool = field(default=False, init=False)

    def __post_init__(self) -> None:
        self.base_dir = os.path.abspath(self.base_dir)
        if not self.mdb_path:
            self.mdb_path = resolve_sys_data_path(self.base_dir)
        if not self.user_data_path:
            self.user_data_path = self.session.user_data_path
        self.data_dict = DataDictionary(self.mdb_path)
        self.program_repo = ProgramRepository(self.mdb_path)

    def reload_metadata(self) -> None:
        self.data_dict.load()
        self.program_repo.load()
        self.program_repo.apply_permission_filter(
            self.session.group_level, self.session.company_key
        )
        self._program_loaded = True

    def close(self) -> None:
        """Web session 結束；共用 ODBC 連線由 access_pool 管理，不在此關閉。"""
        self._program_loaded = False


class AppService:
    """桌面與 Web 共用的業務邏輯。"""

    def __init__(self, base_dir: str) -> None:
        self.base_dir = os.path.abspath(base_dir)

    def list_companies(self) -> Tuple[List[str], Optional[str]]:
        user_data_path = resolve_user_data_path(self.base_dir)
        return load_company_keys(user_data_path)

    def detect_last_company(
        self, user_no: str, password: str
    ) -> Tuple[Optional[str], Optional[str]]:
        user_data_path = resolve_user_data_path(self.base_dir)
        return detect_last_company_by_credentials(user_data_path, user_no, password)

    def login(
        self,
        user_no: str,
        password: str,
        company_key: str,
        *,
        record_success: bool = True,
    ) -> Tuple[Optional[AppRuntime], Optional[str]]:
        user_data_path = resolve_user_data_path(self.base_dir)
        co = (company_key or "").strip()
        if co:
            db_err = validate_company_db(self.base_dir, co)
            if db_err:
                return None, db_err
        session, err = authenticate(user_data_path, user_no, password, company_key)
        if err or session is None:
            return None, err or "登入失敗。"
        if not co:
            db_err = validate_company_db(self.base_dir, session.company_key)
            if db_err:
                return None, db_err
        if record_success:
            rec_err = record_login_success(user_data_path, user_no, company_key)
            if rec_err:
                return None, rec_err
        runtime = AppRuntime(base_dir=self.base_dir, session=session)
        runtime.reload_metadata()
        return runtime, None

    def create_runtime_from_session(self, session: UserSession) -> AppRuntime:
        runtime = AppRuntime(base_dir=self.base_dir, session=session)
        runtime.reload_metadata()
        return runtime

    def menu_groups(self, runtime: AppRuntime) -> List[MainMenuGroup]:
        return runtime.program_repo.mainmenu_groups

    def set_language(self, runtime: AppRuntime, lang: LanguageCode) -> None:
        runtime.lang = lang

    def _resolve_program_db_path(
        self, runtime: AppRuntime, prg: Optional[ProgramItem]
    ) -> tuple[str, Optional[str]]:
        work_db = (getattr(prg, "work_db", None) or "").strip() if prg else ""
        if work_db:
            meta_path = resolve_metadata_db_path(runtime.base_dir, work_db)
            if meta_path:
                return meta_path, None
            if os.path.isabs(work_db):
                return work_db, None
            root, ext = os.path.splitext(work_db)
            if ext:
                cand = os.path.join(runtime.base_dir, work_db)
                if os.path.isfile(cand):
                    return cand, None
                low = work_db.lower()
                if low.endswith(".mdb"):
                    sqlite_cand = os.path.join(
                        runtime.base_dir, root + ".sqlite"
                    )
                    if os.path.isfile(sqlite_cand):
                        return sqlite_cand, None
                return cand, None
            return ensure_company_db_path(runtime.base_dir, work_db)
        prg_co = (getattr(prg, "co_key", None) or "").strip() if prg else ""
        key, err = resolve_program_company_key(prg_co, runtime.session.company_key)
        if err:
            return "", err
        return ensure_company_db_path(runtime.base_dir, key)

    @staticmethod
    def _parse_tx_files(tx_file_value: Optional[str]) -> List[str]:
        if not tx_file_value:
            return []
        raw = tx_file_value.replace(";", ",").replace("|", ",").replace("，", ",")
        out: List[str] = []
        seen = set()
        for part in raw.split(","):
            name = part.strip()
            if not name:
                continue
            key = name.upper()
            if key in seen:
                continue
            seen.add(key)
            out.append(name)
        return out

    def _backend_for_path(self, runtime: AppRuntime, db_path: str) -> DbBackendBase:
        return get_backend_for_path(db_path)

    def _column_meta_dict(
        self,
        runtime: AppRuntime,
        table_name: str,
        field_names: List[str],
    ) -> List[Dict[str, Any]]:
        lang = runtime.lang
        out: List[Dict[str, Any]] = []
        for name in field_names:
            meta: Optional[ColumnTitle] = runtime.data_dict._meta(table_name, name)
            if meta is None:
                out.append(
                    {
                        "name": name,
                        "title": name,
                        "data_type": "",
                        "data_format": "",
                        "edit_tab": "",
                        "grid_width_chars": 0,
                        "align": "left",
                    }
                )
                continue
            out.append(
                {
                    "name": meta.name,
                    "title": meta.get_title(lang),
                    "data_type": meta.data_type or "",
                    "data_format": meta.data_format or "",
                    "edit_tab": meta.edit_tab or "",
                    "grid_width_chars": meta.grid_width_chars,
                    "need_attach": meta.need_attach,
                    "attach_path": meta.attach_path or "",
                    "need_other": meta.need_other,
                    "other_title": meta.other_title or "",
                    "align": grid_column_align(
                        meta.name, meta.data_format or "", meta.data_type or ""
                    ),
                }
            )
        return out

    @staticmethod
    def _work_actions_dict(flags: WorkActionFlags) -> Dict[str, Any]:
        return {
            "need_attach": bool(flags.need_attach),
            "attach_path": flags.attach_path or "",
            "attach_key": flags.attach_key or "",
            "need_other": bool(flags.need_other),
            "other_title": flags.other_title or "",
        }

    @staticmethod
    def _resolve_update_where(
        physical_fields: List[str],
        old_row: List[str],
        print_doc_key_column: Optional[str] = None,
    ) -> Tuple[List[str], List[str]]:
        """與 WorkPage 相同：優先用 KEY_CODE / TX_KEY / ID 作 WHERE。"""
        candidates: List[str] = []
        for c in (
            (print_doc_key_column or "").strip(),
            "TX_KEY",
            "ID",
        ):
            if c and c.upper() not in [x.upper() for x in candidates]:
                candidates.append(c)
        for col in candidates:
            try:
                idx = next(
                    i
                    for i, name in enumerate(physical_fields)
                    if name.strip().upper() == col.strip().upper()
                )
            except StopIteration:
                continue
            if idx < len(old_row):
                v = (old_row[idx] or "").strip()
                if v:
                    return [physical_fields[idx]], [old_row[idx]]
        return list(physical_fields), list(old_row)

    def _form_values_from_row(
        self,
        runtime: AppRuntime,
        table_name: str,
        form_fields: List[str],
        physical_fields: List[str],
        physical_row: List[str],
    ) -> Dict[str, str]:
        out: Dict[str, str] = {}
        for f in form_fields:
            try:
                i = physical_fields.index(f)
                raw = str(physical_row[i]) if i < len(physical_row) else ""
                f_fmt = runtime.data_dict.get_data_format(table_name, f)
                f_typ = runtime.data_dict.get_data_type(table_name, f)
                out[f] = format_cell_display(f, raw, f_fmt, f_typ)
            except ValueError:
                out[f] = ""
        return out

    def _resolve_master_tx_key(
        self,
        runtime: AppRuntime,
        schema: WorkSchema,
        physical_row: List[str],
    ) -> Tuple[Optional[str], Optional[str]]:
        """回傳 (鍵欄位名, 鍵值) 供 TX 明細過濾。"""
        key_col = schema.print_doc_key_column
        if key_col:
            try:
                idx = schema.physical_fields.index(key_col)
                val = (physical_row[idx] or "").strip() if idx < len(physical_row) else ""
                if val:
                    return key_col, val
            except ValueError:
                pass
        for col in schema.physical_fields:
            if col.strip().upper() == "TX_KEY":
                idx = schema.physical_fields.index(col)
                val = (physical_row[idx] or "").strip() if idx < len(physical_row) else ""
                if val:
                    return col, val
        return None, None

    def resolve_work(
        self,
        runtime: AppRuntime,
        do_proc: str,
        *,
        reload_program: bool = False,
    ) -> Tuple[Optional[WorkSchema], Optional[str]]:
        if not os.path.isfile(runtime.mdb_path):
            return None, f"找不到系統資料庫：{runtime.mdb_path}"

        if reload_program or not runtime._program_loaded:
            runtime.program_repo.load()
            runtime.program_repo.apply_permission_filter(
                runtime.session.group_level, runtime.session.company_key
            )
            runtime._program_loaded = True

        binding = runtime.program_repo.resolve_program_binding(do_proc)
        prg = binding.menu_item
        table_name = binding.work_file
        resolved_proc = binding.rule_proc
        data_prg = binding.data_item
        resolved_prg = runtime.program_repo.find_by_do_proc(resolved_proc)

        runtime.data_dict.set_rule_alias(table_name, resolved_proc)

        tx_files = runtime.program_repo.list_tx_files_by_do_proc(do_proc)
        if not tx_files and resolved_proc:
            tx_files = runtime.program_repo.list_tx_files_by_do_proc(resolved_proc)
        if not tx_files:
            tx_files = self._parse_tx_files(prg.tx_file if prg else None)
        if not tx_files and resolved_prg is not None:
            tx_files = self._parse_tx_files(resolved_prg.tx_file)
        for tx_table in tx_files:
            runtime.data_dict.ensure_tx_column_rules(tx_table, resolved_proc)

        db_path, co_err = self._resolve_program_db_path(runtime, data_prg or prg)
        if co_err:
            return None, co_err
        backend = self._backend_for_path(runtime, db_path)
        physical = backend.list_columns(table_name)
        if not physical:
            return (
                None,
                f"找不到資料表「{table_name}」或無法讀取欄位（資料庫：{os.path.basename(db_path)}）。",
            )
        grid_fields = runtime.data_dict.grid_columns_for_table(table_name, physical)
        form_fields = runtime.data_dict.edit_columns_for_table(table_name, physical)
        menu_title = prg.get_title(runtime.lang) if prg else do_proc
        key_col = None
        if resolved_prg and resolved_prg.key_code:
            key_col = resolved_prg.key_code.strip() or None
        if not key_col and prg and prg.key_code:
            key_col = prg.key_code.strip() or None

        work_actions = resolve_work_actions_for_program(
            runtime.data_dict,
            table_name,
            do_proc,
            prg,
            resolved_prg,
            data_prg,
        )
        schema = WorkSchema(
            do_proc=do_proc,
            table_name=table_name,
            rule_proc=resolved_proc,
            db_path=db_path,
            grid_fields=grid_fields,
            form_fields=form_fields,
            physical_fields=physical,
            tx_files=tx_files,
            menu_title=menu_title,
            columns=self._column_meta_dict(runtime, table_name, grid_fields),
            form_columns=self._column_meta_dict(runtime, table_name, form_fields),
            print_doc_key_column=key_col,
            work_actions=work_actions,
        )
        return schema, None

    def schema_to_dict(self, runtime: AppRuntime, schema: WorkSchema) -> Dict[str, Any]:
        return {
            "do_proc": schema.do_proc,
            "table_name": schema.table_name,
            "menu_title": schema.menu_title,
            "fields": schema.grid_fields,
            "physical_fields": schema.physical_fields,
            "form_fields": schema.form_fields,
            "columns": schema.columns,
            "form_columns": schema.form_columns,
            "tx_files": schema.tx_files,
            "print_doc_key_column": schema.print_doc_key_column,
            "work_actions": self._work_actions_dict(schema.work_actions),
            "lang": runtime.lang,
        }

    @staticmethod
    def _grid_phys_indices(grid_fields: List[str], physical_fields: List[str]) -> List[int]:
        indices: List[int] = []
        for f in grid_fields:
            try:
                indices.append(physical_fields.index(f))
            except ValueError:
                indices.append(-1)
        return indices

    @staticmethod
    def _map_rows_to_grid(
        grid_fields: List[str], physical_fields: List[str], rows: List[List[str]]
    ) -> List[List[str]]:
        indices = AppService._grid_phys_indices(grid_fields, physical_fields)
        mapped: List[List[str]] = []
        for row in rows:
            line: List[str] = []
            for idx in indices:
                if 0 <= idx < len(row):
                    line.append(row[idx])
                else:
                    line.append("")
            mapped.append(line)
        return mapped

    def _format_rows_for_grid_display(
        self,
        runtime: AppRuntime,
        table_name: str,
        grid_fields: List[str],
        grid_rows: List[List[str]],
    ) -> List[List[str]]:
        out: List[List[str]] = []
        for row in grid_rows:
            line: List[str] = []
            for i, field in enumerate(grid_fields):
                raw = row[i] if i < len(row) else ""
                f_fmt = runtime.data_dict.get_data_format(table_name, field)
                f_typ = runtime.data_dict.get_data_type(table_name, field)
                line.append(format_cell_display(field, raw, f_fmt, f_typ))
            out.append(line)
        return out

    def fetch_rows(
        self,
        runtime: AppRuntime,
        do_proc: str,
        keyword: str = "",
        as_filter: bool = False,
        limit: int = 500,
        *,
        reload_program: bool = False,
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        schema, err = self.resolve_work(
            runtime, do_proc, reload_program=reload_program
        )
        if err or schema is None:
            return None, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        physical_rows = backend.fetch_rows(
            schema.table_name,
            keyword,
            as_filter,
            limit=limit,
            column_order=schema.physical_fields,
        )
        grid_rows = self._map_rows_to_grid(
            schema.grid_fields, schema.physical_fields, physical_rows
        )
        display_rows = self._format_rows_for_grid_display(
            runtime, schema.table_name, schema.grid_fields, grid_rows
        )
        return {
            "do_proc": do_proc,
            "table_name": schema.table_name,
            "fields": schema.grid_fields,
            "physical_fields": schema.physical_fields,
            "form_fields": schema.form_fields,
            "form_columns": schema.form_columns,
            "columns": schema.columns,
            "rows": display_rows,
            "physical_rows": physical_rows,
            "total": len(grid_rows),
            "print_doc_key_column": schema.print_doc_key_column,
            "tx_files": schema.tx_files,
            "menu_title": schema.menu_title,
            "work_actions": self._work_actions_dict(schema.work_actions),
        }, None

    def insert_row(
        self,
        runtime: AppRuntime,
        do_proc: str,
        values: Dict[str, str],
    ) -> Tuple[bool, Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return False, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        field_names = [f for f in schema.form_fields if f in values]
        row_values = []
        for f in field_names:
            raw = values.get(f, "")
            f_fmt = runtime.data_dict.get_data_format(schema.table_name, f)
            f_typ = runtime.data_dict.get_data_type(schema.table_name, f)
            row_values.append(normalize_storage_value(f, f_fmt, raw, f_typ))
        ok = backend.insert_one(schema.table_name, field_names, row_values)
        if not ok:
            return False, getattr(backend, "last_error", "") or "新增失敗。"
        return True, None

    def update_row(
        self,
        runtime: AppRuntime,
        do_proc: str,
        new_values: Dict[str, str],
        old_row: List[str],
    ) -> Tuple[bool, Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return False, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        set_fields = [f for f in schema.form_fields if f in new_values]
        set_values = []
        for f in set_fields:
            raw = new_values.get(f, "")
            f_fmt = runtime.data_dict.get_data_format(schema.table_name, f)
            f_typ = runtime.data_dict.get_data_type(schema.table_name, f)
            set_values.append(normalize_storage_value(f, f_fmt, raw, f_typ))
        where_fields, where_vals = self._resolve_update_where(
            schema.physical_fields,
            old_row,
            schema.print_doc_key_column,
        )
        ok = backend.update_one(
            schema.table_name,
            set_fields,
            set_values,
            where_fields,
            where_vals,
        )
        if not ok:
            return False, getattr(backend, "last_error", "") or "更新失敗。"
        return True, None

    def delete_row(
        self,
        runtime: AppRuntime,
        do_proc: str,
        old_row: List[str],
    ) -> Tuple[bool, Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return False, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        where_fields, where_vals = self._resolve_update_where(
            schema.physical_fields,
            old_row,
            schema.print_doc_key_column,
        )
        ok = backend.delete_one(schema.table_name, where_fields, where_vals)
        if not ok:
            return False, getattr(backend, "last_error", "") or "刪除失敗。"
        return True, None

    def get_form_values(
        self,
        runtime: AppRuntime,
        do_proc: str,
        physical_row: List[str],
    ) -> Tuple[Optional[Dict[str, str]], Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return None, err or "無法解析作業。"
        return self._form_values_from_row(
            runtime,
            schema.table_name,
            schema.form_fields,
            schema.physical_fields,
            physical_row,
        ), None

    def fetch_tx_rows(
        self,
        runtime: AppRuntime,
        do_proc: str,
        tx_table: str,
        master_row: List[str],
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return None, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        physical = backend.list_columns(tx_table)
        if not physical:
            physical = ["LINE_NO", "ITEM_CODE", "QTY", "PRICE", "AMOUNT"]
        grid_fields = runtime.data_dict.grid_columns_for_table(tx_table, physical)
        if not grid_fields:
            grid_fields = runtime.data_dict.edit_columns_for_table(tx_table, physical)
        if not grid_fields:
            grid_fields = list(physical)
        key_col, key_val = self._resolve_master_tx_key(runtime, schema, master_row)

        rows: List[List[str]] = []
        if key_col and key_val:
            rows = backend.fetch_rows_where(
                tx_table, key_col, key_val, limit=200, column_order=physical
            )
        grid_rows = self._map_rows_to_grid(grid_fields, physical, rows)
        display_rows = self._format_rows_for_grid_display(
            runtime, tx_table, grid_fields, grid_rows
        )
        return {
            "tx_table": tx_table,
            "fields": grid_fields,
            "physical_fields": physical,
            "columns": self._column_meta_dict(runtime, tx_table, grid_fields),
            "rows": display_rows,
            "physical_rows": [list(r) for r in rows],
            "read_only": False,
            "filter_column": key_col,
            "filter_value": key_val,
        }, None

    @staticmethod
    def _resolve_tx_filter_column(
        tx_physical: List[str],
        master_key_col: Optional[str],
    ) -> Optional[str]:
        if master_key_col:
            want = master_key_col.strip().upper()
            for c in tx_physical:
                if c.strip().upper() == want:
                    return c
        for c in tx_physical:
            if c.strip().upper() == "TX_KEY":
                return c
        return None

    def _resolve_master_tx_key_from_form(
        self,
        runtime: AppRuntime,
        schema: WorkSchema,
        form_values: Dict[str, str],
        master_row: List[str],
    ) -> Tuple[Optional[str], Optional[str]]:
        if schema.print_doc_key_column:
            pk = schema.print_doc_key_column
            if pk in form_values and (form_values.get(pk) or "").strip():
                return pk, form_values[pk].strip()
            try:
                idx = schema.physical_fields.index(pk)
                if idx < len(master_row) and (master_row[idx] or "").strip():
                    return pk, master_row[idx].strip()
            except ValueError:
                pass
        for f in schema.form_fields:
            if f.strip().upper() == "TX_KEY":
                v = (form_values.get(f) or "").strip()
                if v:
                    return f, v
                try:
                    idx = schema.physical_fields.index(f)
                    if idx < len(master_row) and (master_row[idx] or "").strip():
                        return f, master_row[idx].strip()
                except ValueError:
                    pass
        return self._resolve_master_tx_key(runtime, schema, master_row)

    def save_tx_rows(
        self,
        runtime: AppRuntime,
        do_proc: str,
        tx_table: str,
        physical_rows: List[List[str]],
        master_form_values: Dict[str, str],
        master_row: Optional[List[str]] = None,
    ) -> Tuple[bool, Optional[str]]:
        """與 TxDetailGridPane.save_to_backend 相同：刪除同鍵舊明細後整批重寫。"""
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return False, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        physical = backend.list_columns(tx_table)
        if not physical:
            physical = ["LINE_NO", "ITEM_CODE", "QTY", "PRICE", "AMOUNT"]

        master_row = list(master_row or [])
        master_key_col, master_key_val = self._resolve_master_tx_key_from_form(
            runtime, schema, master_form_values, master_row
        )
        key_col = self._resolve_tx_filter_column(physical, master_key_col)

        if master_key_val and not key_col:
            return False, f"{tx_table}: 找不到 TX 鍵欄位。"

        key_value = master_key_val
        if key_col and key_value is not None:
            key_fmt = runtime.data_dict.get_data_format(tx_table, key_col)
            key_typ = runtime.data_dict.get_data_type(tx_table, key_col)
            key_value = normalize_storage_value(key_col, key_fmt, key_value, key_typ)

        if key_value and key_col:
            existing = backend.fetch_rows_where(
                tx_table, key_col, key_value, limit=500, column_order=physical
            )
            if existing:
                if not backend.delete_one(tx_table, [key_col], [key_value]):
                    be = getattr(backend, "last_error", "") or ""
                    return False, be or f"{tx_table}: 刪除舊明細失敗。"

        auto_like = {"ID", "AUTOID", "AUTO_ID", "RECNO", "REC_NO"}
        string_types = {"S", "STRING", "STR", "TEXT", "CHAR", "VARCHAR", "NVARCHAR"}
        key_idx = None
        if key_col:
            for i, c in enumerate(physical):
                if c.strip().upper() == key_col.strip().upper():
                    key_idx = i
                    break

        for src in physical_rows:
            row = list(src[: len(physical)])
            while len(row) < len(physical):
                row.append("")
            if key_idx is not None and key_value is not None:
                row[key_idx] = key_value

            meaningful = False
            for i, v in enumerate(row):
                if key_idx is not None and i == key_idx:
                    continue
                if str(v or "").strip():
                    meaningful = True
                    break
            if not meaningful:
                continue

            insert_fields: List[str] = []
            insert_values: List[str] = []
            for i, col in enumerate(physical):
                col_up = col.strip().upper()
                if key_idx is not None and i == key_idx and key_value is not None:
                    insert_fields.append(col)
                    insert_values.append(key_value)
                    continue
                if col_up in auto_like:
                    continue
                raw = row[i] if i < len(row) else ""
                txt = str(raw).strip()
                if not txt:
                    dtyp = runtime.data_dict.get_data_type(tx_table, col).strip().upper()
                    if dtyp not in string_types:
                        continue
                fmt = runtime.data_dict.get_data_format(tx_table, col)
                dtyp = runtime.data_dict.get_data_type(tx_table, col)
                norm = normalize_storage_value(col, fmt, str(raw), dtyp)
                insert_fields.append(col)
                insert_values.append(norm)

            if not insert_fields:
                continue
            if not backend.insert_one(tx_table, insert_fields, insert_values):
                be = getattr(backend, "last_error", "") or ""
                return False, be or f"{tx_table}: 寫入明細失敗。"
        return True, None

    def resolve_attachments(
        self,
        runtime: AppRuntime,
        do_proc: str,
        old_row: List[str],
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        """與 WorkPage._on_attachment 相同邏輯，回傳 Web 可用的附件清單。"""
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return None, err or "無法解析作業。"
        if not old_row:
            return None, "請先選取一筆記錄。"
        key_code = schema.print_doc_key_column or ""
        lookup_col, key_value, folder, files = resolve_attachments_for_row(
            schema.work_actions.attach_path,
            schema.work_actions.attach_key,
            key_code,
            schema.physical_fields,
            old_row,
            co_key=runtime.session.company_key,
            do_proc=do_proc,
            table_name=schema.table_name,
            app_base_dir=runtime.base_dir,
        )
        if not lookup_col:
            return None, "未設定 ATTACH_KEY 或 KEY_CODE 欄位。"
        if not key_value:
            return None, f"目前記錄的「{lookup_col}」為空白，無法搜尋附件。"
        file_items = []
        for fp in files:
            name = os.path.basename(fp)
            kind = "pdf" if is_pdf_path(fp) else "image" if is_image_path(fp) else "other"
            file_items.append({"path": fp, "name": name, "kind": kind})
        return {
            "lookup_column": lookup_col,
            "key_value": key_value,
            "folder": folder,
            "files": file_items,
        }, None

    @staticmethod
    def _settlement_line_dict(ln: SettlementLine) -> Dict[str, Any]:
        return {
            "tx_key": ln.tx_key,
            "inv_no": ln.inv_no,
            "date": ln.date,
            "currency": ln.currency,
            "rate": ln.rate,
            "net_amt": ln.net_amt,
            "paid_amt": ln.paid_amt,
            "balance": ln.balance,
            "pay_amount": ln.pay_amount,
            "discount": ln.discount,
            "in_trx": ln.in_trx,
            "old_pay_amount": ln.old_pay_amount,
            "old_discount": ln.old_discount,
        }

    @staticmethod
    def _settlement_line_from_dict(d: Dict[str, Any]) -> SettlementLine:
        return SettlementLine(
            tx_key=str(d.get("tx_key") or ""),
            inv_no=str(d.get("inv_no") or ""),
            date=str(d.get("date") or ""),
            currency=str(d.get("currency") or ""),
            rate=str(d.get("rate") or ""),
            net_amt=str(d.get("net_amt") or ""),
            paid_amt=str(d.get("paid_amt") or ""),
            balance=str(d.get("balance") or ""),
            pay_amount=str(d.get("pay_amount") or ""),
            discount=str(d.get("discount") or ""),
            in_trx=bool(d.get("in_trx")),
            old_pay_amount=str(d.get("old_pay_amount") or ""),
            old_discount=str(d.get("old_discount") or ""),
        )

    @classmethod
    def _settlement_doc_dict(cls, doc: SettlementDocument) -> Dict[str, Any]:
        h = doc.header
        return {
            "mode": doc.mode,
            "header": {
                "vou_key": h.vou_key,
                "settle_date": h.settle_date,
                "party_key": h.party_key,
                "party_name": h.party_name,
                "settle_amount": h.settle_amount,
                "exchange_diff": h.exchange_diff,
            },
            "lines": [cls._settlement_line_dict(ln) for ln in doc.lines],
        }

    @classmethod
    def _settlement_doc_from_dict(cls, data: Dict[str, Any]) -> SettlementDocument:
        hdr = data.get("header") or {}
        header = SettlementHeader(
            vou_key=str(hdr.get("vou_key") or ""),
            settle_date=str(hdr.get("settle_date") or ""),
            party_key=str(hdr.get("party_key") or ""),
            party_name=str(hdr.get("party_name") or ""),
            settle_amount=str(hdr.get("settle_amount") or ""),
            exchange_diff=str(hdr.get("exchange_diff") or ""),
        )
        lines = [
            cls._settlement_line_from_dict(x)
            for x in (data.get("lines") or [])
        ]
        mode = data.get("mode") or "AR"
        return SettlementDocument(mode=mode, header=header, lines=lines)

    @staticmethod
    def _settlement_totals_dict(doc: SettlementDocument) -> Dict[str, str]:
        bal, pay, disc = sum_totals(doc.lines)
        exch = doc.header.exchange_diff or "0"
        from decimal import Decimal

        rem = remaining_settlement(
            Decimal(str(doc.header.settle_amount or "0").replace(",", "")),
            pay,
            disc,
            Decimal(str(exch or "0").replace(",", "")),
        )
        return {
            "total_balance": format(bal, "f"),
            "total_pay": format(pay, "f"),
            "total_discount": format(disc, "f"),
            "remaining": format(rem, "f"),
        }

    def load_arap_settlement(
        self,
        runtime: AppRuntime,
        do_proc: str,
        old_row: List[str],
    ) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return None, err or "無法解析作業。"
        if not old_row:
            return None, "請先選取一筆傳票記錄。"
        other_title = schema.work_actions.other_title or ""
        if not is_arap_settlement_program(do_proc, schema.table_name, other_title):
            return None, "此作業非應收應付清賬。"
        backend = self._backend_for_path(runtime, schema.db_path)
        doc, load_err = load_settlement(
            backend,
            do_proc,
            old_row,
            schema.physical_fields,
            table_name=schema.table_name,
            other_title=other_title,
        )
        if load_err or doc is None:
            return None, load_err or "無法載入清賬資料。"
        payload = self._settlement_doc_dict(doc)
        payload["totals"] = self._settlement_totals_dict(doc)
        payload["lang"] = runtime.lang
        return payload, None

    def save_arap_settlement(
        self,
        runtime: AppRuntime,
        do_proc: str,
        document: Dict[str, Any],
    ) -> Tuple[bool, Optional[str]]:
        schema, err = self.resolve_work(runtime, do_proc, reload_program=False)
        if err or schema is None:
            return False, err or "無法解析作業。"
        backend = self._backend_for_path(runtime, schema.db_path)
        doc = self._settlement_doc_from_dict(document)
        return save_settlement(backend, doc)

    def auto_arap_settlement(
        self,
        document: Dict[str, Any],
    ) -> Dict[str, Any]:
        doc = self._settlement_doc_from_dict(document)
        auto_settle_lines(
            doc.lines,
            doc.header.settle_amount,
            doc.header.exchange_diff,
        )
        payload = self._settlement_doc_dict(doc)
        payload["totals"] = self._settlement_totals_dict(doc)
        return payload

    def filter_arap_lines(
        self,
        document: Dict[str, Any],
        keyword: str,
        *,
        as_filter: bool = False,
    ) -> Dict[str, Any]:
        doc = self._settlement_doc_from_dict(document)
        if as_filter:
            lines = filter_lines(doc.lines, keyword)
        else:
            idx = find_line_index(doc.lines, keyword)
            lines = list(doc.lines)
            payload = self._settlement_doc_dict(doc)
            payload["selected_index"] = idx
            payload["totals"] = self._settlement_totals_dict(doc)
            return payload
        doc.lines = lines
        payload = self._settlement_doc_dict(doc)
        payload["totals"] = self._settlement_totals_dict(doc)
        return payload
