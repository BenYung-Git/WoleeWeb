from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    user_no: str
    password: str
    company_key: str = ""


class LoginResponse(BaseModel):
    token: str = ""
    user_no: str
    company_key: str
    group_no: str = ""


class SessionResponse(BaseModel):
    user_no: str
    company_key: str
    group_no: str = ""


class CompanyListResponse(BaseModel):
    companies: List[str]


class LastCompanyRequest(BaseModel):
    user_no: str
    password: str


class LastCompanyResponse(BaseModel):
    company_key: Optional[str] = None


class MenuItemResponse(BaseModel):
    do_proc: str
    title: str
    work_file: Optional[str] = None
    icon: str = "applications-system"
    need_attach: bool = False
    attach_path: str = ""
    attach_key: str = ""
    need_other: bool = False
    other_title: str = ""


class MenuGroupResponse(BaseModel):
    menu_type: str
    title: str
    items: List[MenuItemResponse]


class MenuResponse(BaseModel):
    groups: List[MenuGroupResponse]
    lang: str


class AttachmentFileItem(BaseModel):
    path: str
    name: str
    kind: str = "other"


class AttachmentResolveResponse(BaseModel):
    lookup_column: str = ""
    key_value: str = ""
    folder: str = ""
    files: List[AttachmentFileItem] = Field(default_factory=list)


class ArapSettlementHeader(BaseModel):
    vou_key: str = ""
    settle_date: str = ""
    party_key: str = ""
    party_name: str = ""
    settle_amount: str = ""
    exchange_diff: str = ""


class ArapSettlementLine(BaseModel):
    tx_key: str = ""
    inv_no: str = ""
    date: str = ""
    currency: str = ""
    rate: str = ""
    net_amt: str = ""
    paid_amt: str = ""
    balance: str = ""
    pay_amount: str = ""
    discount: str = ""
    in_trx: bool = False
    old_pay_amount: str = ""
    old_discount: str = ""


class ArapSettlementDocument(BaseModel):
    mode: str = "AR"
    header: ArapSettlementHeader = Field(default_factory=ArapSettlementHeader)
    lines: List[ArapSettlementLine] = Field(default_factory=list)


class ArapLoadResponse(BaseModel):
    mode: str = "AR"
    header: ArapSettlementHeader
    lines: List[ArapSettlementLine] = Field(default_factory=list)
    totals: Dict[str, str] = Field(default_factory=dict)
    lang: str = "CHN"
    selected_index: Optional[int] = None


class ArapFilterRequest(BaseModel):
    document: Dict[str, Any] = Field(default_factory=dict)
    keyword: str = ""
    as_filter: bool = False


class ArapSaveRequest(BaseModel):
    document: Dict[str, Any] = Field(default_factory=dict)


class SetLanguageRequest(BaseModel):
    lang: Literal["CHN", "ENG"]


class WorkSchemaResponse(BaseModel):
    do_proc: str
    table_name: str
    menu_title: str
    fields: List[str]
    physical_fields: List[str] = Field(default_factory=list)
    form_fields: List[str] = Field(default_factory=list)
    columns: List[Dict[str, Any]]
    form_columns: List[Dict[str, Any]] = Field(default_factory=list)
    tx_files: List[str] = Field(default_factory=list)
    print_doc_key_column: Optional[str] = None
    work_actions: Dict[str, Any] = Field(default_factory=dict)
    lang: str = "CHN"


class WorkRowsResponse(BaseModel):
    do_proc: str
    table_name: str
    menu_title: str = ""
    fields: List[str]
    physical_fields: List[str] = Field(default_factory=list)
    form_fields: List[str] = Field(default_factory=list)
    form_columns: List[Dict[str, Any]] = Field(default_factory=list)
    columns: List[Dict[str, Any]]
    rows: List[List[str]]
    physical_rows: List[List[str]] = Field(default_factory=list)
    total: int
    tx_files: List[str] = Field(default_factory=list)
    print_doc_key_column: Optional[str] = None
    work_actions: Dict[str, Any] = Field(default_factory=dict)


class TxRowsRequest(BaseModel):
    physical_row: List[str] = Field(default_factory=list)


class TxSaveRequest(BaseModel):
    physical_rows: List[List[str]] = Field(default_factory=list)
    master_form_values: Dict[str, str] = Field(default_factory=dict)
    master_row: List[str] = Field(default_factory=list)


class TxRowsResponse(BaseModel):
    tx_table: str
    fields: List[str]
    physical_fields: List[str] = Field(default_factory=list)
    columns: List[Dict[str, Any]]
    rows: List[List[str]]
    physical_rows: List[List[str]] = Field(default_factory=list)
    read_only: bool = False
    filter_column: Optional[str] = None
    filter_value: Optional[str] = None


class FetchRowsRequest(BaseModel):
    keyword: str = ""
    as_filter: bool = False
    limit: int = 500
    reload_program: bool = False


class RowMutationRequest(BaseModel):
    values: Dict[str, str] = Field(default_factory=dict)
    old_row: List[str] = Field(default_factory=list)


class OkResponse(BaseModel):
    ok: bool = True
    message: str = ""


class ErrorResponse(BaseModel):
    detail: str


class PrintInitRequest(BaseModel):
    selected_row: Optional[int] = None


class PrintReportItem(BaseModel):
    index: int
    title: str
    rpt_type: str = ""


class PrintPrinterItem(BaseModel):
    index: int
    name: str


class PrintInitResponse(BaseModel):
    no_report: bool
    message: Optional[str] = None
    doc_no_label: str
    reports: List[PrintReportItem]
    printers: List[PrintPrinterItem]
    report_index: int = 0
    printer_index: int = 0
    inv_from: str = ""
    inv_to: str = ""
    date_from: str = ""
    date_to: str = ""
    lang: str = "CHN"
    is_list: bool = False
    is_document: bool = False


class PrintParamsRequest(BaseModel):
    report_index: int = 0
    printer_index: int = 0
    inv_from: str = ""
    inv_to: str = ""
    date_from: str = ""
    date_to: str = ""


class PrintDefaultsRequest(BaseModel):
    report_index: int = 0


class PrintDefaultsResponse(BaseModel):
    inv_from: str = ""
    inv_to: str = ""
    date_from: str = ""
    date_to: str = ""
    is_list: bool = False
    is_document: bool = False


class PrintPickColumnItem(BaseModel):
    name: str
    title: str = ""


class PrintPickRowsResponse(BaseModel):
    ok: bool = True
    fields: List[str] = []
    columns: List[PrintPickColumnItem] = []
    rows: List[List[str]] = []
    key_values: List[str] = []


class PrintPreviewResponse(BaseModel):
    ok: bool
    message: str = ""
    kind: Literal["html", "pdf"] = "html"
    html: Optional[str] = None
    pdfs_base64: Optional[List[str]] = None


class PrintActionResponse(BaseModel):
    ok: bool
    message: str = ""


class PrintEmailTextResponse(BaseModel):
    subject: str = ""
    plain_text: str = ""
    hint: str = ""
