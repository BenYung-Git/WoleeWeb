from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import threading
from typing import Callable, Optional

import uvicorn
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles

from api.schemas import (
    ArapFilterRequest,
    ArapLoadResponse,
    ArapSaveRequest,
    AttachmentResolveResponse,
    CompanyListResponse,
    FetchRowsRequest,
    LastCompanyRequest,
    LastCompanyResponse,
    LoginRequest,
    LoginResponse,
    SessionResponse,
    MenuGroupResponse,
    MenuItemResponse,
    MenuResponse,
    OkResponse,
    PrintActionResponse,
    PrintEmailTextResponse,
    PrintDefaultsRequest,
    PrintDefaultsResponse,
    PrintInitRequest,
    PrintInitResponse,
    PrintParamsRequest,
    PrintPickRowsResponse,
    PrintPreviewResponse,
    PrintPrinterItem,
    PrintReportItem,
    RowMutationRequest,
    SetLanguageRequest,
    TxRowsRequest,
    TxRowsResponse,
    TxSaveRequest,
    WorkRowsResponse,
    WorkSchemaResponse,
)
from api.session_store import session_store
from api.network import local_browser_url, print_web_startup_banner, web_access_urls
from services.app_service import AppService
from services.print_report_service import PrintReportService
from core.attachment_service import is_image_path, is_pdf_path
from core.menu_icon_resolver import resolve_menu_item_icon_key

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_STATIC_DIR = os.path.join(_ROOT, "web", "static")


def _get_base_dir() -> str:
    return _ROOT


def _get_app_service() -> AppService:
    return AppService(_get_base_dir())


def _extract_token(request: Request) -> str:
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return request.headers.get("X-Session-Token", "").strip()


def _require_runtime(request: Request) -> "AppRuntime":
    from services.app_service import AppRuntime

    token = _extract_token(request)
    runtime = session_store.get(token)
    if runtime is None:
        raise HTTPException(status_code=401, detail="未登入或 session 已過期。")
    return runtime


def create_app(base_dir: Optional[str] = None) -> FastAPI:
    if base_dir:
        global _ROOT
        _ROOT = os.path.abspath(base_dir)

    app = FastAPI(title="企業管理系統 Web API", version="1.0.0")
    svc = AppService(_ROOT if base_dir is None else os.path.abspath(base_dir))
    print_svc = PrintReportService(svc)

    @app.get("/api/health")
    def health() -> dict:
        return {"status": "ok", "mode": "web"}

    @app.get("/api/companies", response_model=CompanyListResponse)
    def list_companies() -> CompanyListResponse:
        companies, err = svc.list_companies()
        if err:
            raise HTTPException(status_code=500, detail=err)
        return CompanyListResponse(companies=companies or ["GS"])

    @app.post("/api/auth/last-company", response_model=LastCompanyResponse)
    def last_company(body: LastCompanyRequest) -> LastCompanyResponse:
        last_co, err = svc.detect_last_company(body.user_no, body.password)
        if err:
            raise HTTPException(status_code=500, detail=err)
        return LastCompanyResponse(company_key=last_co)

    @app.post("/api/auth/login", response_model=LoginResponse)
    def login(body: LoginRequest) -> LoginResponse:
        runtime, err = svc.login(body.user_no, body.password, body.company_key)
        if err or runtime is None:
            raise HTTPException(status_code=401, detail=err or "登入失敗。")
        token = session_store.create(runtime)
        return LoginResponse(
            token=token,
            user_no=runtime.session.user_no,
            company_key=runtime.session.company_key,
            group_no=runtime.session.group_no,
        )

    @app.get("/api/auth/me", response_model=SessionResponse)
    def auth_me(runtime=Depends(_require_runtime)) -> SessionResponse:
        return SessionResponse(
            user_no=runtime.session.user_no,
            company_key=runtime.session.company_key,
            group_no=runtime.session.group_no,
        )

    @app.post("/api/auth/logout", response_model=OkResponse)
    def logout(request: Request) -> OkResponse:
        token = _extract_token(request)
        if token:
            session_store.remove(token)
        return OkResponse(message="已登出。")

    @app.get("/api/menu", response_model=MenuResponse)
    def get_menu(runtime=Depends(_require_runtime)) -> MenuResponse:
        groups = []
        for g in svc.menu_groups(runtime):
            items = [
                MenuItemResponse(
                    do_proc=it.do_proc,
                    title=it.get_title(runtime.lang),
                    work_file=it.work_file,
                    icon=resolve_menu_item_icon_key(
                        it.do_proc, it.get_title(runtime.lang)
                    ),
                    need_attach=bool(getattr(it, "need_attach", False)),
                    attach_path=(getattr(it, "attach_path", None) or "").strip(),
                    attach_key=(getattr(it, "attach_key", None) or "").strip(),
                    need_other=bool(getattr(it, "need_other", False)),
                    other_title=(getattr(it, "other_title", None) or "").strip(),
                )
                for it in g.items
            ]
            groups.append(
                MenuGroupResponse(
                    menu_type=g.menu_type,
                    title=g.get_title(runtime.lang),
                    items=items,
                )
            )
        return MenuResponse(groups=groups, lang=runtime.lang)

    @app.post("/api/settings/language", response_model=OkResponse)
    def set_language(body: SetLanguageRequest, runtime=Depends(_require_runtime)) -> OkResponse:
        svc.set_language(runtime, body.lang)
        return OkResponse(message="語言已更新。")

    @app.get("/api/work/{do_proc}/schema", response_model=WorkSchemaResponse)
    def work_schema(do_proc: str, runtime=Depends(_require_runtime)) -> WorkSchemaResponse:
        schema, err = svc.resolve_work(runtime, do_proc, reload_program=True)
        if err or schema is None:
            raise HTTPException(status_code=400, detail=err or "無法開啟作業。")
        return WorkSchemaResponse(**svc.schema_to_dict(runtime, schema))

    @app.post("/api/work/{do_proc}/rows", response_model=WorkRowsResponse)
    def work_rows(
        do_proc: str,
        body: FetchRowsRequest,
        runtime=Depends(_require_runtime),
    ) -> WorkRowsResponse:
        data, err = svc.fetch_rows(
            runtime,
            do_proc,
            keyword=body.keyword,
            as_filter=body.as_filter,
            limit=body.limit,
            reload_program=body.reload_program,
        )
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "查詢失敗。")
        return WorkRowsResponse(**data)

    @app.post("/api/work/{do_proc}/insert", response_model=OkResponse)
    def insert_row(
        do_proc: str,
        body: RowMutationRequest,
        runtime=Depends(_require_runtime),
    ) -> OkResponse:
        ok, err = svc.insert_row(runtime, do_proc, body.values)
        if not ok:
            raise HTTPException(status_code=400, detail=err or "新增失敗。")
        return OkResponse(message="新增成功。")

    @app.put("/api/work/{do_proc}/update", response_model=OkResponse)
    def update_row(
        do_proc: str,
        body: RowMutationRequest,
        runtime=Depends(_require_runtime),
    ) -> OkResponse:
        ok, err = svc.update_row(runtime, do_proc, body.values, body.old_row)
        if not ok:
            raise HTTPException(status_code=400, detail=err or "更新失敗。")
        return OkResponse(message="更新成功。")

    @app.delete("/api/work/{do_proc}/delete", response_model=OkResponse)
    def delete_row(
        do_proc: str,
        body: RowMutationRequest,
        runtime=Depends(_require_runtime),
    ) -> OkResponse:
        ok, err = svc.delete_row(runtime, do_proc, body.old_row)
        if not ok:
            raise HTTPException(status_code=400, detail=err or "刪除失敗。")
        return OkResponse(message="刪除成功。")

    @app.post("/api/work/{do_proc}/tx/{tx_table}/rows", response_model=TxRowsResponse)
    def tx_rows(
        do_proc: str,
        tx_table: str,
        body: TxRowsRequest,
        runtime=Depends(_require_runtime),
    ) -> TxRowsResponse:
        data, err = svc.fetch_tx_rows(runtime, do_proc, tx_table, body.physical_row)
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "查詢明細失敗。")
        return TxRowsResponse(**data)

    @app.post("/api/work/{do_proc}/form-values")
    def form_values(
        do_proc: str,
        body: RowMutationRequest,
        runtime=Depends(_require_runtime),
    ) -> dict:
        values, err = svc.get_form_values(runtime, do_proc, body.old_row)
        if err or values is None:
            raise HTTPException(status_code=400, detail=err or "無法讀取表單。")
        return {"values": values}

    @app.put("/api/work/{do_proc}/tx/{tx_table}/save", response_model=OkResponse)
    def save_tx_rows(
        do_proc: str,
        tx_table: str,
        body: TxSaveRequest,
        runtime=Depends(_require_runtime),
    ) -> OkResponse:
        ok, err = svc.save_tx_rows(
            runtime,
            do_proc,
            tx_table,
            body.physical_rows,
            body.master_form_values,
            body.master_row,
        )
        if not ok:
            raise HTTPException(status_code=400, detail=err or "儲存明細失敗。")
        return OkResponse(message="明細已儲存。")

    @app.post("/api/work/{do_proc}/attachments", response_model=AttachmentResolveResponse)
    def resolve_attachments(
        do_proc: str,
        body: RowMutationRequest,
        runtime=Depends(_require_runtime),
    ) -> AttachmentResolveResponse:
        data, err = svc.resolve_attachments(runtime, do_proc, body.old_row)
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "無法解析附件。")
        return AttachmentResolveResponse(**data)

    @app.get("/api/attachments/file")
    def attachment_file(
        path: str,
        request: Request,
        runtime=Depends(_require_runtime),
    ):
        """提供附件預覽（僅限 resolve_attachments 回傳之路徑）。"""
        token = _extract_token(request)
        if not token:
            raise HTTPException(status_code=401, detail="未登入。")
        fp = os.path.normpath(os.path.abspath(path or ""))
        if not os.path.isfile(fp):
            raise HTTPException(status_code=404, detail="找不到檔案。")
        if not (is_pdf_path(fp) or is_image_path(fp)):
            raise HTTPException(status_code=400, detail="不支援的附件類型。")
        media = "application/pdf" if is_pdf_path(fp) else "application/octet-stream"
        ext = os.path.splitext(fp)[1].lower()
        if ext in (".jpg", ".jpeg"):
            media = "image/jpeg"
        elif ext == ".png":
            media = "image/png"
        elif ext == ".gif":
            media = "image/gif"
        elif ext == ".webp":
            media = "image/webp"
        elif ext in (".tif", ".tiff"):
            media = "image/tiff"
        elif ext == ".bmp":
            media = "image/bmp"
        return FileResponse(fp, media_type=media, filename=os.path.basename(fp))

    @app.post("/api/work/{do_proc}/arap/load", response_model=ArapLoadResponse)
    def arap_load(
        do_proc: str,
        body: RowMutationRequest,
        runtime=Depends(_require_runtime),
    ) -> ArapLoadResponse:
        data, err = svc.load_arap_settlement(runtime, do_proc, body.old_row)
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "無法載入清賬。")
        return ArapLoadResponse(**data)

    @app.put("/api/work/{do_proc}/arap/save", response_model=OkResponse)
    def arap_save(
        do_proc: str,
        body: ArapSaveRequest,
        runtime=Depends(_require_runtime),
    ) -> OkResponse:
        ok, err = svc.save_arap_settlement(runtime, do_proc, body.document)
        if not ok:
            raise HTTPException(status_code=400, detail=err or "清賬儲存失敗。")
        return OkResponse(message="清賬已儲存。")

    @app.post("/api/work/{do_proc}/arap/auto", response_model=ArapLoadResponse)
    def arap_auto(
        do_proc: str,
        body: ArapSaveRequest,
        runtime=Depends(_require_runtime),
    ) -> ArapLoadResponse:
        data = svc.auto_arap_settlement(body.document)
        return ArapLoadResponse(**data)

    @app.post("/api/work/{do_proc}/arap/filter", response_model=ArapLoadResponse)
    def arap_filter(
        do_proc: str,
        body: ArapFilterRequest,
        runtime=Depends(_require_runtime),
    ) -> ArapLoadResponse:
        data = svc.filter_arap_lines(
            body.document,
            body.keyword,
            as_filter=body.as_filter,
        )
        return ArapLoadResponse(**data)

    def _print_init_response(data: dict) -> PrintInitResponse:
        return PrintInitResponse(
            no_report=data.get("no_report", False),
            message=data.get("message"),
            doc_no_label=data.get("doc_no_label", ""),
            reports=[PrintReportItem(**r) for r in data.get("reports", [])],
            printers=[PrintPrinterItem(**p) for p in data.get("printers", [])],
            report_index=data.get("report_index", 0),
            printer_index=data.get("printer_index", 0),
            inv_from=data.get("inv_from", ""),
            inv_to=data.get("inv_to", ""),
            date_from=data.get("date_from", ""),
            date_to=data.get("date_to", ""),
            lang=data.get("lang", "CHN"),
            is_list=data.get("is_list", False),
            is_document=data.get("is_document", False),
        )

    def _print_api_error(exc: BaseException) -> HTTPException:
        if isinstance(exc, TimeoutError):
            return HTTPException(status_code=504, detail=str(exc) or "列印操作逾時。")
        if isinstance(exc, RuntimeError):
            return HTTPException(status_code=503, detail=str(exc) or "列印服務不可用。")
        return HTTPException(status_code=500, detail=str(exc) or "列印失敗。")

    @app.post("/api/work/{do_proc}/print/init", response_model=PrintInitResponse)
    def print_init(
        do_proc: str,
        body: PrintInitRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ) -> PrintInitResponse:
        token = _extract_token(request)
        try:
            data, err = print_svc.init_dialog(token, runtime, do_proc, body.selected_row)
        except (RuntimeError, TimeoutError) as exc:
            raise _print_api_error(exc) from exc
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "無法初始化列印。")
        return _print_init_response(data)

    @app.post("/api/work/{do_proc}/print/defaults", response_model=PrintDefaultsResponse)
    def print_defaults(
        do_proc: str,
        body: PrintDefaultsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ) -> PrintDefaultsResponse:
        token = _extract_token(request)
        try:
            data, err = print_svc.apply_defaults_on_report_change(
                token, do_proc, body.report_index
            )
        except (RuntimeError, TimeoutError) as exc:
            raise _print_api_error(exc) from exc
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "無法更新預設值。")
        return PrintDefaultsResponse(**data)

    @app.post("/api/work/{do_proc}/print/pick-rows", response_model=PrintPickRowsResponse)
    def print_pick_rows(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ) -> PrintPickRowsResponse:
        token = _extract_token(request)
        try:
            data, err = print_svc.pick_rows(token, do_proc, body.model_dump())
        except (RuntimeError, TimeoutError) as exc:
            raise _print_api_error(exc) from exc
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "無法取得選取資料。")
        return PrintPickRowsResponse(**data)

    @app.post("/api/work/{do_proc}/print/preview", response_model=PrintPreviewResponse)
    def print_preview(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ) -> PrintPreviewResponse:
        token = _extract_token(request)
        try:
            data, err = print_svc.preview(token, do_proc, body.model_dump())
        except (RuntimeError, TimeoutError) as exc:
            raise _print_api_error(exc) from exc
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "預覽失敗。")
        return PrintPreviewResponse(**data)

    @app.post("/api/work/{do_proc}/print/email-text", response_model=PrintEmailTextResponse)
    def print_email_text(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ) -> PrintEmailTextResponse:
        token = _extract_token(request)
        try:
            data, err = print_svc.email_text(token, do_proc, body.model_dump())
        except (RuntimeError, TimeoutError) as exc:
            raise _print_api_error(exc) from exc
        if err or data is None:
            raise HTTPException(status_code=400, detail=err or "無法取得郵件內容。")
        return PrintEmailTextResponse(**data)

    @app.post("/api/work/{do_proc}/print/print", response_model=PrintActionResponse)
    def print_execute(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ) -> PrintActionResponse:
        token = _extract_token(request)
        ok, msg = print_svc.print_report(token, do_proc, body.model_dump())
        if not ok:
            raise HTTPException(status_code=400, detail=msg or "列印失敗。")
        return PrintActionResponse(ok=True, message=msg)

    @app.post("/api/work/{do_proc}/print/export/pdf")
    def print_export_pdf(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ):
        token = _extract_token(request)
        ok, msg, data = print_svc.export_pdf(token, do_proc, body.model_dump())
        if not ok:
            raise HTTPException(status_code=400, detail=msg or "匯出 PDF 失敗。")
        title = (runtime.lang == "CHN" and "report") or "report"
        return Response(
            content=data,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{title}.pdf"'},
        )

    @app.post("/api/work/{do_proc}/print/export/xlsx")
    def print_export_xlsx(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ):
        token = _extract_token(request)
        ok, msg, data = print_svc.export_xlsx(token, do_proc, body.model_dump())
        if not ok:
            raise HTTPException(status_code=400, detail=msg or "匯出 XLSX 失敗。")
        return Response(
            content=data,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": 'attachment; filename="report.xlsx"'},
        )

    @app.post("/api/work/{do_proc}/print/export/docx")
    def print_export_docx(
        do_proc: str,
        body: PrintParamsRequest,
        request: Request,
        runtime=Depends(_require_runtime),
    ):
        token = _extract_token(request)
        ok, msg, data = print_svc.export_docx(token, do_proc, body.model_dump())
        if not ok:
            raise HTTPException(status_code=400, detail=msg or "匯出 DOCX 失敗。")
        return Response(
            content=data,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": 'attachment; filename="report.docx"'},
        )

    @app.get("/")
    def index():
        index_path = os.path.join(_STATIC_DIR, "index.html")
        if os.path.isfile(index_path):
            return FileResponse(index_path)
        raise HTTPException(status_code=404, detail="Web 前端未安裝。")

    if os.path.isdir(_STATIC_DIR):
        app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")

    return app


class _SuppressUvicornShutdownNoise(logging.Filter):
    """關閉時 uvicorn/starlette lifespan 的 CancelledError 為正常現象，不印 ERROR。"""

    def filter(self, record: logging.LogRecord) -> bool:
        if record.levelno < logging.ERROR:
            return True
        if record.exc_info:
            exc_type = record.exc_info[0]
            if exc_type is asyncio.CancelledError:
                return False
        msg = record.getMessage()
        return "CancelledError" not in msg and "lifespan" not in msg.lower()


class _WoleeUvicornServer(uvicorn.Server):
    """收到 SIGINT/SIGTERM 時除停止 uvicorn 外，可呼叫額外關閉回呼（例如結束 Qt 事件迴圈）。"""

    shutdown_hook: Optional[Callable[[], None]] = None

    def handle_exit(self, sig, frame) -> None:  # noqa: ARG002
        super().handle_exit(sig, frame)
        hook = self.shutdown_hook
        if hook is None:
            return
        try:
            hook()
        except Exception:
            pass


def _uvicorn_config(app, host: str, port: int) -> uvicorn.Config:
    """建立 uvicorn 設定；關閉 lifespan 可避免 Ctrl+C 時 lifespan CancelledError 噪音。"""
    cfg = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level="warning",
        access_log=False,
        lifespan="off",
    )
    for name in ("uvicorn.error", "uvicorn"):
        logging.getLogger(name).addFilter(_SuppressUvicornShutdownNoise())
    return cfg


class WebServerManager:
    """背景 Web 伺服器管理（桌面/Web 雙模式切換用）。"""

    _instance: Optional["WebServerManager"] = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._server: Optional[_WoleeUvicornServer] = None
        self._host = "0.0.0.0"
        self._port = 8080
        self._base_dir = _ROOT
        self._running = False
        self._shutdown_lock = threading.Lock()
        self._shutdown_hook: Optional[Callable[[], None]] = None

    @classmethod
    def instance(cls) -> "WebServerManager":
        with cls._lock:
            if cls._instance is None:
                cls._instance = WebServerManager()
            return cls._instance

    @property
    def is_running(self) -> bool:
        return self._running and self._thread is not None and self._thread.is_alive()

    @property
    def url(self) -> str:
        return local_browser_url(self._host, self._port)

    @property
    def access_urls(self) -> list[str]:
        return web_access_urls(self._host, self._port)

    def configure(
        self,
        host: str = "0.0.0.0",
        port: int = 8080,
        base_dir: Optional[str] = None,
        shutdown_hook: Optional[Callable[[], None]] = None,
    ) -> None:
        self._host = host
        self._port = port
        if base_dir:
            self._base_dir = os.path.abspath(base_dir)
        if shutdown_hook is not None:
            self._shutdown_hook = shutdown_hook

    def start(self, blocking: bool = False) -> bool:
        if self.is_running:
            return True

        app = create_app(self._base_dir)
        hook = self._shutdown_hook

        def _run() -> None:
            self._running = True
            server: Optional[_WoleeUvicornServer] = None
            try:
                print_web_startup_banner(self._host, self._port)
                config = _uvicorn_config(app, self._host, self._port)
                server = _WoleeUvicornServer(config)
                server.shutdown_hook = hook
                with self._shutdown_lock:
                    self._server = server
                server.run()
            finally:
                self._running = False
                with self._shutdown_lock:
                    if server is not None and self._server is server:
                        self._server = None

        if blocking:
            _run()
            return True

        self._thread = threading.Thread(
            target=_run, daemon=True, name="WoleeWebServer"
        )
        self._thread.start()
        return True

    def request_shutdown(self) -> None:
        """從主控台 Ctrl+C 等觸發：先優雅結束 uvicorn（不立即 force_exit）。"""
        with self._shutdown_lock:
            server = self._server
            if server is not None:
                server.should_exit = True

    def stop(self, timeout: float = 8.0) -> None:
        with self._shutdown_lock:
            self._running = False
            server = self._server
            if server is not None:
                server.should_exit = True
            thread = self._thread
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=timeout)
            if thread.is_alive() and server is not None:
                with self._shutdown_lock:
                    server.force_exit = True
                thread.join(timeout=min(timeout, 3.0))
        with self._shutdown_lock:
            if self._thread is thread and not (thread and thread.is_alive()):
                self._thread = None


def install_main_thread_interrupt(
    mgr: WebServerManager,
    extra: Optional[Callable[[], None]] = None,
) -> None:
    """
    主執行緒額外註冊 Ctrl+C：停止 uvicorn 並執行 extra（例如 app.quit）。
    uvicorn 在背景執行緒時，僅靠其 signal handler 可能無法結束 Qt 事件迴圈。
    """

    def _handle(signum, frame) -> None:  # noqa: ARG001
        sig_name = "SIGINT" if signum == signal.SIGINT else "SIGTERM"
        print(f"\n收到 {sig_name}，正在停止伺服器…", flush=True)
        mgr.stop()
        if extra is not None:
            try:
                extra()
            except Exception:
                pass
        raise KeyboardInterrupt

    signal.signal(signal.SIGINT, _handle)
    signal.signal(signal.SIGTERM, _handle)
    if sys.platform == "win32" and hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, _handle)


def run_server(host: str = "0.0.0.0", port: int = 8080, base_dir: Optional[str] = None) -> None:
    """前景執行 Web 伺服器（web 模式）。"""
    mgr = WebServerManager.instance()
    mgr.configure(host=host, port=port, base_dir=base_dir)
    try:
        mgr.start(blocking=True)
    except KeyboardInterrupt:
        print("\n已停止。", flush=True)
    finally:
        mgr.stop()
